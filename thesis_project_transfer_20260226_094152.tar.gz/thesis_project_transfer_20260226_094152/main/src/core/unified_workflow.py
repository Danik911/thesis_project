"""
Unified Test Generation Workflow - Master Orchestrator

This module implements the master workflow that orchestrates all components
of the pharmaceutical test generation system into one cohesive workflow.
It chains together GAMP-5 categorization, test planning, and parallel agent
execution to provide complete end-to-end test generation capabilities.

Key Features:
- Complete workflow orchestration from URS to test generation results
- Integration of categorization → planning → parallel execution → results
- GAMP-5 compliance with complete audit trail
- Error handling and human consultation triggers
- Phoenix observability integration
- Regulatory compliance (ALCOA+, 21 CFR Part 11)

Workflow Flow:
1. URS Document Input → GAMPCategorizationWorkflow
2. GAMPCategorizationEvent → PlannerAgentWorkflow
3. Parallel Agent Coordination (Context, SME, Research)
4. Result Compilation and Final Output
"""

import logging
import sys
import yaml
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from langfuse import observe
from llama_index.core.llms import LLM
from llama_index.core.workflow import Context, StartEvent, StopEvent, Workflow, step

from src.agents.oq_generator.events import OQTestGenerationEvent, OQTestSuiteEvent
from src.agents.oq_generator.workflow import OQGenerationWorkflow

# Import 21 CFR Part 11 compliance systems
from src.compliance import (
    get_mfa_service,
    get_rbac_system,
    get_signature_service,
    get_training_system,
    get_validation_framework,
    get_worm_storage,
)
from src.compliance.alcoa_validator import ALCOAPlusValidator
from src.compliance.part11_signatures import SignatureMeaning

# from llama_index.llms.openai import OpenAI  # Migrated to centralized LLM config
from src.config.llm_config import LLMConfig
from src.core.categorization_workflow import GAMPCategorizationWorkflow
from src.core.consultation_handler import process_consultation_input
from src.core.consultation_utils import derive_consultation_triggers
from src.core.events import (
    AgentRequestEvent,
    AgentResultEvent,
    AgentResultsEvent,
    ConsultationBypassedEvent,
    ConsultationInputEvent,
    ConsultationRequiredEvent,
    GAMPCategorizationEvent,
    GAMPCategory,
    PlanningEvent,
    SignedAgentResultsEvent,
    URSIngestionEvent,
)
from src.core.human_consultation import (
    HumanConsultationManager,
)
from main.src.exceptions import HumanApprovalRequired
from src.monitoring.phoenix_config import setup_phoenix
from src.monitoring.simple_tracer import get_tracer

# Enhanced Phoenix Observability - temporarily disabled for testing
# from src.monitoring.phoenix_enhanced import (
#     PhoenixEnhancedClient,
#     AutomatedTraceAnalyzer,
#     WorkflowEventFlowVisualizer
# )
from src.shared.config import get_config

# Set up configuration
config = get_config()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def flush_output():
    """Ensure terminal output is displayed immediately."""
    sys.stdout.flush()
    sys.stderr.flush()


async def show_progress_during_wait(coro, timeout, operation_name="Operation", agent_type="agent"):
    """
    Execute a coroutine with progress indicators to prevent terminal blocking.
    
    Enhanced with faster updates and immediate flush for better user experience
    during human consultation workflows.
    
    Args:
        coro: Coroutine to execute
        timeout: Timeout in seconds
        operation_name: Name of the operation for display
        agent_type: Type of agent for logging
        
    Returns:
        Result of the coroutine
    """
    import asyncio
    import time

    start_time = time.time()
    print(f"🔄 {operation_name} for {agent_type} agent starting (timeout: {timeout}s)...")
    flush_output()

    # Create progress task with special handling for consultation
    async def show_progress():
        elapsed = 0
        update_interval = 1.0 if "consultation" in operation_name.lower() else 2.0
        while True:
            await asyncio.sleep(update_interval)
            elapsed = time.time() - start_time
            remaining = max(0, timeout - elapsed)

            # Special message for consultation operations
            if "consultation" in operation_name.lower():
                print(f"   👤 Waiting for human consultation: {elapsed:.0f}s elapsed, {remaining:.0f}s remaining...")
            else:
                print(f"   ⏱️  {operation_name}: {elapsed:.0f}s elapsed, {remaining:.0f}s remaining...")
            flush_output()

    # Start progress indicator
    progress_task = asyncio.create_task(show_progress())

    try:
        # Execute the main operation with timeout
        result = await asyncio.wait_for(coro, timeout=timeout)
        elapsed = time.time() - start_time
        print(f"✅ {operation_name} completed successfully in {elapsed:.1f}s")
        flush_output()
        return result
    except TimeoutError:
        elapsed = time.time() - start_time
        print(f"❌ {operation_name} timed out after {elapsed:.1f}s")
        flush_output()
        raise
    finally:
        # Cancel progress indicator
        progress_task.cancel()
        try:
            await progress_task
        except asyncio.CancelledError:
            pass


# Safe context management functions for preventing state failures
# Using ctx.store for persistent cross-workflow state management
# Sentinel value to distinguish "no default provided" from "default=None"
_NO_DEFAULT = object()

async def safe_context_get(ctx: Context, key: str, default=_NO_DEFAULT):
    """
    Safe context retrieval with persistent storage and explicit error handling.

    Args:
        ctx: Workflow context
        key: Context key to retrieve
        default: Default value if key not found or error occurs (can be None)

    Returns:
        Retrieved value or default

    Raises:
        RuntimeError: If critical state retrieval fails with no fallback allowed
    """
    try:
        # ENHANCED: Add detailed logging for debugging
        logger.debug(f"[CTX] Attempting to retrieve context key: {key}")

        # Use ctx.store for persistent storage across workflow boundaries
        value = await ctx.store.get(key)
        if value is not None:
            # ENHANCED: Log value type for debugging complex objects
            logger.debug(f"[CTX] Context retrieval successful for key {key}, type: {type(value)}")
            return value

        # Check if default was explicitly provided (even if None)
        if default is not _NO_DEFAULT:
            logger.debug(f"[CTX] Context key {key} not found, returning default: {default}")
            return default

        # NO FALLBACKS - explicit failure for critical state when no default provided
        logger.error(f"[CRITICAL] Context key '{key}' not found in persistent store and no default provided")

        # ENHANCED: Add context diagnosis for debugging
        all_keys = []
        try:
            # Try to get all available keys for debugging
            for test_key in ["workflow_start_time", "categorization_result", "planning_event", "gamp_category"]:
                try:
                    test_value = await ctx.store.get(test_key)
                    if test_value is not None:
                        all_keys.append(test_key)
                except:
                    pass
            logger.error(f"[CTX] Available context keys: {all_keys}")
        except Exception as diag_error:
            logger.error(f"Context diagnosis failed: {diag_error}")

        raise RuntimeError(f"Critical state '{key}' not found in workflow context - workflow state corrupted")
    except Exception as e:
        # CRITICAL FIX: If default was provided, return it instead of raising
        # This handles cases where ctx.store.get() raises an exception (not just returns None)
        if default is not _NO_DEFAULT:
            logger.warning(f"[CTX] Context retrieval exception for key {key}, returning default: {e}")
            return default

        # NO FALLBACKS - fail explicitly for regulatory compliance ONLY if no default
        logger.error(f"[ERROR] Context retrieval failed for key {key}: {e}")
        raise RuntimeError(f"Context storage system failure for key '{key}': {e!s}") from e


async def safe_context_set(ctx: Context, key: str, value):
    """
    Safe context storage with persistent storage and explicit error handling.
    
    Enhanced with comprehensive state transition audit logging for regulatory compliance.
    
    Args:
        ctx: Workflow context
        key: Context key to store
        value: Value to store
        
    Returns:
        bool: True if successful
        
    Raises:
        RuntimeError: If critical state storage fails (no fallback allowed)
    """
    try:
        # Initialize audit trail for state transition logging
        from src.core.audit_trail import get_audit_trail
        audit_trail = get_audit_trail()

        # ENHANCED: Add detailed logging for debugging
        logger.debug(f"[CTX] Attempting to store context key: {key}, type: {type(value)}")

        # Get previous value for state transition tracking
        previous_value = None
        try:
            previous_value = await ctx.store.get(key)
        except Exception:
            pass  # New key, no previous value

        # ENHANCED: Handle complex objects that might need special serialization
        if hasattr(value, "__dict__") and not isinstance(value, (str, int, float, bool, list, dict)):
            logger.debug(f"[CTX] Storing complex object {key}: {type(value)}")
            # For GAMPCategory enum, store both value and type info
            if hasattr(value, "value") and hasattr(value, "__class__"):
                logger.debug(f"[CTX] Enum detected for {key}: {value.value}")

        # Use ctx.store for persistent storage across workflow boundaries
        await ctx.store.set(key, value)
        logger.debug(f"[CTX] Context storage successful for key {key}")

        # Log state transition for audit trail
        audit_trail.log_state_transition(
            from_state=f"context_{key}_previous" if previous_value is not None else "context_key_not_exists",
            to_state=f"context_{key}_stored",
            transition_trigger="safe_context_set",
            transition_metadata={
                "context_key": key,
                "value_type": type(value).__name__,
                "previous_value_existed": previous_value is not None,
                "storage_method": "ctx.store.set",
                "verification_enabled": True
            },
            workflow_step="context_management",
            state_data={
                "key": key,
                "value_type": type(value).__name__,
                "value_summary": str(value)[:100] + "..." if len(str(value)) > 100 else str(value)
            },
            workflow_context={
                "context_operation": "storage",
                "regulatory_compliance": "GAMP-5",
                "audit_trail_enabled": True
            }
        )

        # ENHANCED: Verify storage by reading back
        try:
            verification = await ctx.store.get(key)
            if verification is None:
                logger.warning(f"[WARNING] Verification failed: {key} was stored but read back as None")

                # Log verification failure
                audit_trail.log_error_recovery(
                    error_type="context_verification_failure",
                    error_message=f"Context key {key} was stored but verification read returned None",
                    error_context={
                        "context_key": key,
                        "storage_successful": True,
                        "verification_failed": True
                    },
                    recovery_strategy="continue_with_warning",
                    recovery_actions=["log_warning", "continue_operation"],
                    recovery_success=True,
                    workflow_step="context_management"
                )
            else:
                logger.debug(f"[CTX] Storage verification successful for {key}")
        except Exception as verify_error:
            logger.warning(f"[WARNING] Storage verification failed for {key}: {verify_error}")

            # Log verification error
            audit_trail.log_error_recovery(
                error_type="context_verification_error",
                error_message=str(verify_error),
                error_context={
                    "context_key": key,
                    "storage_successful": True,
                    "verification_exception": type(verify_error).__name__
                },
                recovery_strategy="continue_with_warning",
                recovery_actions=["log_warning", "continue_operation"],
                recovery_success=True,
                workflow_step="context_management"
            )

        return True
    except Exception as e:
        logger.error(f"[CRITICAL] Context storage failed for key {key}: {e}")

        # Log critical context storage failure
        from src.core.audit_trail import get_audit_trail
        audit_trail = get_audit_trail()
        audit_trail.log_error_recovery(
            error_type="critical_context_storage_failure",
            error_message=str(e),
            error_context={
                "context_key": key,
                "value_type": type(value).__name__ if value is not None else "None",
                "error_type": type(e).__name__,
                "fallback_prevented": True
            },
            recovery_strategy="no_fallback_explicit_failure",
            recovery_actions=["log_error", "raise_runtime_error"],
            recovery_success=False,
            workflow_step="context_management",
            workflow_context={
                "regulatory_compliance": "GAMP-5",
                "audit_trail_preserved": True,
                "error_transparency": "complete"
            }
        )

        # NO FALLBACKS - fail explicitly for regulatory compliance
        raise RuntimeError(f"Context storage system failure for key '{key}': {e!s}") from e


async def validate_workflow_state(ctx: Context, required_keys: list[str]) -> bool:
    """
    Validate that all required workflow state keys exist in persistent storage.
    
    Args:
        ctx: Workflow context
        required_keys: List of required context keys
        
    Returns:
        bool: True if all keys exist
        
    Raises:
        RuntimeError: If any critical state is missing (no fallback allowed)
    """
    missing_keys = []
    for key in required_keys:
        try:
            value = await ctx.store.get(key)
            if value is None:
                missing_keys.append(key)
        except Exception as e:
            logger.error(f"State validation failed for key {key}: {e}")
            missing_keys.append(key)

    if missing_keys:
        error_msg = f"GAMP-5 Compliance Violation: Critical workflow state missing: {missing_keys}"
        logger.error(error_msg)
        # NO FALLBACKS - fail explicitly for regulatory compliance
        raise RuntimeError(error_msg)

    logger.info(f"GAMP-5 State Validation: PASSED - All required keys present: {required_keys}")
    return True


async def log_state_operation(operation: str, key: str, success: bool, error: str = None):
    """
    Log state operations for GAMP-5 audit trail compliance.
    
    Args:
        operation: Operation type (get/set/validate)
        key: Context key
        success: Whether operation succeeded
        error: Error message if failed
    """
    from datetime import UTC, datetime

    audit_entry = {
        "timestamp": datetime.now(UTC).isoformat(),
        "operation": f"context_{operation}",
        "key": key,
        "success": success,
        "error": error,
        "compliance_level": "GAMP-5"
    }

    if success:
        logger.info(f"GAMP-5 Audit: {operation.upper()} successful for key '{key}'")
    else:
        logger.error(f"GAMP-5 Audit: {operation.upper()} failed for key '{key}': {error}")


class UnifiedTestGenerationWorkflow(Workflow):
    """
    Master workflow that orchestrates complete pharmaceutical test generation.
    
    This workflow implements the complete end-to-end test generation process:
    1. Document ingestion and parsing
    2. GAMP-5 categorization
    3. Test planning with risk assessment
    4. Parallel agent coordination (Context, SME, Research)
    5. Test generation and validation
    6. Final result compilation with audit trail
    
    The workflow maintains regulatory compliance throughout and provides
    comprehensive observability through Phoenix monitoring.
    """

    def __init__(
        self,
        timeout: int = 1800,  # 30 minutes for complete workflow (increased for FDA API latency)
        verbose: bool = False,
        enable_phoenix: bool = True,
        enable_parallel_coordination: bool = True,
        enable_human_consultation: bool = True,
        llm: LLM | None = None,
        enable_part11_compliance: bool = True,
        user_session_id: str | None = None,
        approved_category: int | None = None
    ):
        """
        Initialize the unified workflow with 21 CFR Part 11 compliance.

        Args:
            timeout: Maximum time to wait for workflow completion
            verbose: Enable verbose logging
            enable_phoenix: Enable Phoenix observability
            enable_parallel_coordination: Enable parallel agent coordination
            enable_human_consultation: Enable human consultation triggers
            llm: Language model for workflow intelligence
            enable_part11_compliance: Enable 21 CFR Part 11 compliance controls
            user_session_id: Active user session for access control
            approved_category: Pre-approved GAMP category from HIL (skips categorization step)
        """
        super().__init__(timeout=timeout, verbose=verbose)

        # Configuration
        self.timeout = timeout  # Store timeout for access in steps
        self.verbose = verbose
        self.enable_phoenix = enable_phoenix
        self.enable_parallel_coordination = enable_parallel_coordination
        self.enable_human_consultation = enable_human_consultation
        self.enable_part11_compliance = enable_part11_compliance
        self.user_session_id = user_session_id
        self.approved_category = approved_category  # Pre-approved category from HIL (skips categorization)
        self.logger = logging.getLogger(__name__)

        # Log HIL resume if approved_category is set
        if approved_category:
            self.logger.info(
                f"[HIL-RESUME] Workflow initialized with pre-approved category: {approved_category}\n"
                f"  Categorization step will be SKIPPED"
            )

        # Initialize LLM using centralized configuration
        # NO FALLBACKS - LLMConfig handles all errors explicitly
        self.llm = llm or LLMConfig.get_llm()

        # Initialize workflow session
        self._workflow_session_id = f"unified_workflow_{datetime.now(UTC).isoformat()}"
        self.workflow_id = uuid4()  # Unique identifier for ALCOA+ traceability

        # Initialize 21 CFR Part 11 compliance systems
        if enable_part11_compliance:
            self.rbac_system = get_rbac_system()
            self.mfa_service = get_mfa_service()
            self.signature_service = get_signature_service()
            self.worm_storage = get_worm_storage()
            self.training_system = get_training_system()
            self.validation_framework = get_validation_framework()
            self.logger.info("[PART11] 21 CFR Part 11 compliance systems initialized")
        else:
            self.rbac_system = None
            self.mfa_service = None
            self.signature_service = None
            self.worm_storage = None
            self.training_system = None
            self.validation_framework = None

        # Initialize tracer for monitoring and error logging
        self.tracer = get_tracer()
        self.logger.info("[TRACER] Tracer initialized for workflow monitoring")

        # Initialize human consultation manager
        if enable_human_consultation:
            self.human_consultation = HumanConsultationManager()

        # Setup Phoenix if enabled
        if enable_phoenix:
            setup_phoenix()
            self.logger.info("[PHOENIX] Phoenix observability enabled")

        # Initialize agent cache to prevent resource leaks
        self._cached_research_agent = None
        self.logger.debug("[AGENTS] Agent caching initialized for resource management")

    def close(self) -> None:
        """Close workflow and clean up resources."""
        self.logger.debug(f"[CLEANUP] Closing UnifiedWorkflow: {self._workflow_session_id}")
        if self._cached_research_agent:
            self.logger.debug("[CLEANUP] Closing cached research agent")
            self._cached_research_agent.close()
            self._cached_research_agent = None

    def __del__(self):
        """Destructor cleanup as safety net."""
        try:
            self.close()
        except Exception:
            # Ignore cleanup errors in destructor
            pass

    def _check_user_access(self, required_permission: str) -> bool:
        """
        Check if user has required permission for workflow operation.
        
        Args:
            required_permission: Permission required for operation
            
        Returns:
            bool: True if access granted
        """
        if not self.enable_part11_compliance or not self.user_session_id:
            # Compliance disabled or no session - allow access
            return True

        try:
            # Check permission using RBAC system
            has_permission = self.rbac_system.check_permission(
                session_id=self.user_session_id,
                permission=required_permission
            )

            # Log access control event
            from src.core.audit_trail import AuditEventType, get_audit_trail
            audit_trail = get_audit_trail()

            audit_trail.log_part11_compliance_event(
                compliance_event_type=AuditEventType.ACCESS_CONTROL_CHECK,
                user_id=self.user_session_id,
                compliance_data={
                    "permission_required": required_permission,
                    "access_granted": has_permission,
                    "workflow_session": self._workflow_session_id
                },
                regulatory_context={
                    "regulation_section": "21_CFR_11.10(d)",
                    "requirement": "limiting_system_access_to_authorized_individuals"
                }
            )

            if not has_permission:
                self.logger.warning(f"[PART11] Access denied for permission: {required_permission}")

            return has_permission

        except Exception as e:
            self.logger.error(f"[PART11] Access control check failed: {e}")
            # NO FALLBACKS - access control failure must be explicit
            return False

    @step
    @observe(name="unified-workflow-execution", as_type="span")
    async def start_unified_workflow(
        self,
        ctx: Context,
        ev: StartEvent
    ) -> URSIngestionEvent:
        """
        Start the unified workflow with document ingestion.

        Args:
            ctx: Workflow context
            ev: Start event with document path

        Returns:
            URSIngestionEvent to begin document processing
        """
        # Set trace context for job attribution
        # Note: Langfuse @observe decorator handles trace context automatically
        # get_current_trace() not available in this langfuse version
        pass

        # Check user access permission for test generation
        if not self._check_user_access("CREATE_TESTS"):
            raise PermissionError("Access denied: User lacks CREATE_TESTS permission for workflow execution")

        # Initialize comprehensive audit trail for workflow state transitions
        from src.core.audit_trail import get_audit_trail
        audit_trail = get_audit_trail()

        self.logger.info("[WORKFLOW] Starting unified test generation workflow")
        flush_output()

        # Log workflow initiation state transition
        audit_trail.log_state_transition(
            from_state="workflow_not_started",
            to_state="workflow_initializing",
            transition_trigger="start_event_received",
            transition_metadata={
                "workflow_type": "UnifiedTestGenerationWorkflow",
                "session_id": self._workflow_session_id,
                "start_event_type": type(ev).__name__,
                "phoenix_enabled": self.enable_phoenix,
                "parallel_coordination_enabled": self.enable_parallel_coordination
            },
            workflow_step="start_unified_workflow",
            state_data={
                "workflow_session_id": self._workflow_session_id,
                "start_time": datetime.now(UTC).isoformat(),
                "configuration": {
                    "timeout": self.timeout,
                    "verbose": self.verbose,
                    "enable_phoenix": self.enable_phoenix,
                    "enable_parallel_coordination": self.enable_parallel_coordination,
                    "enable_human_consultation": self.enable_human_consultation
                }
            },
            workflow_context={
                "regulatory_standards": ["GAMP-5", "21_CFR_Part_11"],
                "workflow_purpose": "pharmaceutical_test_generation"
            }
        )

        # Extract document path from start event
        document_path = ev.get("document_path") or getattr(ev, "document_path", None)
        if not document_path:
            raise ValueError("Document path is required to start workflow")

        # Load document content
        from pathlib import Path
        doc_path = Path(document_path)
        if not doc_path.exists():
            raise FileNotFoundError(f"Document not found: {document_path}")

        urs_content = doc_path.read_text(encoding="utf-8")

        # OWASP Security Validation - Critical first step
        logger.info(f"[{self._workflow_session_id}] Running OWASP security validation on URS content")

        try:
            from src.security import PharmaceuticalInputSecurityWrapper

            # Initialize security validator
            security_validator = PharmaceuticalInputSecurityWrapper()

            # Validate URS content for security threats
            validation_result = security_validator.validate_urs_content(
                urs_content=urs_content,
                document_name=doc_path.name,
                author="system"
            )

            # CRITICAL: Fail explicitly if security validation fails
            if not validation_result.is_valid:
                error_msg = (
                    f"OWASP security validation FAILED for document {doc_path.name}\n"
                    f"Threat Level: {validation_result.threat_level}\n"
                    f"OWASP Category: {validation_result.owasp_category}\n"
                    f"Detected Patterns: {validation_result.detected_patterns}\n"
                    f"Confidence: {validation_result.confidence_score:.3f}\n"
                    f"Error: {validation_result.error_message}\n"
                    f"NO FALLBACKS ALLOWED - Human consultation required."
                )
                logger.error(f"[{self._workflow_session_id}] {error_msg}")
                raise RuntimeError(error_msg)

            # Log successful security validation
            logger.info(
                f"[{self._workflow_session_id}] OWASP security validation PASSED: "
                f"threat_level={validation_result.threat_level}, "
                f"confidence={validation_result.confidence_score:.3f}"
            )

            # Prepare security metadata for event
            security_metadata = {
                "validation_id": str(validation_result.validation_id),
                "threat_level": validation_result.threat_level.value,
                "owasp_category": validation_result.owasp_category.value,
                "confidence_score": validation_result.confidence_score,
                "detected_patterns": validation_result.detected_patterns,
                "processing_time_ms": validation_result.processing_time_ms,
                "is_valid": validation_result.is_valid
            }

        except ImportError as e:
            error_msg = (
                f"OWASP security framework import failed: {e}\n"
                f"Security validation is REQUIRED for pharmaceutical compliance.\n"
                f"NO FALLBACKS ALLOWED - Human consultation required."
            )
            logger.error(f"[{self._workflow_session_id}] {error_msg}")
            raise RuntimeError(error_msg) from e
        except Exception as e:
            error_msg = (
                f"OWASP security validation engine failed: {e}\n"
                f"Security validation failure prevents workflow execution.\n"
                f"NO FALLBACKS ALLOWED - Human consultation required."
            )
            logger.error(f"[{self._workflow_session_id}] {error_msg}")
            raise RuntimeError(error_msg) from e

        # Log document loading state transition
        audit_trail.log_state_transition(
            from_state="workflow_initializing",
            to_state="document_loaded",
            transition_trigger="document_path_resolved",
            transition_metadata={
                "document_path": document_path,
                "document_name": doc_path.name,
                "document_size": len(urs_content),
                "document_exists": True
            },
            workflow_step="start_unified_workflow",
            state_data={
                "document_metadata": {
                    "path": document_path,
                    "name": doc_path.name,
                    "size_bytes": len(urs_content),
                    "content_preview": urs_content[:200] + "..." if len(urs_content) > 200 else urs_content
                }
            },
            workflow_context={
                "workflow_session_id": self._workflow_session_id,
                "document_processing_step": "content_loading"
            }
        )

        # Store workflow metadata using safe operations
        await safe_context_set(ctx, "workflow_start_time", datetime.now(UTC))
        await safe_context_set(ctx, "workflow_session_id", self._workflow_session_id)
        await safe_context_set(ctx, "document_path", document_path)

        # Create URS ingestion event with all required fields including security metadata
        return URSIngestionEvent(
            urs_content=urs_content,
            document_name=doc_path.name,
            document_version="1.0",  # Default version
            author="system",
            # Security metadata from OWASP validation
            security_validation_result=security_metadata,
            security_threat_level=validation_result.threat_level.value,
            owasp_category=validation_result.owasp_category.value,
            security_confidence=validation_result.confidence_score
        )

    @step
    async def categorize_document(
        self,
        ctx: Context,
        ev: URSIngestionEvent
    ) -> GAMPCategorizationEvent:
        """
        Execute GAMP-5 categorization on the ingested document.

        Args:
            ctx: Workflow context
            ev: URS ingestion event

        Returns:
            GAMPCategorizationEvent with categorization results
        """
        # Initialize comprehensive audit trail for state transitions
        from src.core.audit_trail import get_audit_trail
        audit_trail = get_audit_trail()

        # ============================================================
        # HIL RESUME: Skip categorization if human-approved category exists
        # ============================================================
        if self.approved_category is not None:
            self.logger.info(
                f"[HIL-SKIP] Skipping AI categorization - using human-approved category: {self.approved_category}\n"
                f"  Document: {ev.document_name}\n"
                f"  Reason: Category pre-approved via HIL consultation"
            )
            print(f"\n[HIL-RESUME] Using human-approved GAMP Category: {self.approved_category}")
            flush_output()

            # Map integer to GAMPCategory enum
            category_map = {
                1: GAMPCategory.CATEGORY_1,
                3: GAMPCategory.CATEGORY_3,
                4: GAMPCategory.CATEGORY_4,
                5: GAMPCategory.CATEGORY_5
            }
            approved_gamp_category = category_map.get(self.approved_category)
            if approved_gamp_category is None:
                raise ValueError(f"Invalid approved_category: {self.approved_category}. Must be 1, 3, 4, or 5.")

            # Create categorization event with human-approved category
            categorization_event = GAMPCategorizationEvent(
                gamp_category=approved_gamp_category,
                confidence_score=1.0,  # Human decision = full confidence
                justification=f"Human-approved via HIL consultation. Category {self.approved_category} selected by qualified reviewer.",
                risk_assessment={
                    "category": self.approved_category,
                    "category_description": f"GAMP Category {self.approved_category} - Human-approved",
                    "validation_approach": "Per human reviewer decision",
                    "confidence_score": 1.0,
                    "evidence_strength": "Human approval after HIL consultation",
                    "requires_human_review": False,  # Already reviewed
                    "source": "hil_approval"
                },
                categorized_by="human_approval_hil",
                review_required=False,  # Already reviewed by human
                has_ambiguity_signals=False,  # Resolved by human
                ambiguity_details=None,
                alternative_categories=None
            )

            # Store categorization results in context
            await safe_context_set(ctx, "categorization_result", categorization_event)
            await safe_context_set(ctx, "gamp_category", approved_gamp_category)

            # Log HIL skip to audit trail
            audit_trail.log_state_transition(
                from_state="document_loaded",
                to_state="categorization_completed_hil",
                transition_trigger="hil_approved_category",
                transition_metadata={
                    "document_name": ev.document_name,
                    "approved_category": self.approved_category,
                    "categorization_source": "human_approval",
                    "ai_categorization_skipped": True
                },
                workflow_step="categorize_document",
                state_data={
                    "current_step": "gamp_categorization_hil_skip",
                    "human_approved_category": self.approved_category,
                    "confidence_score": 1.0
                },
                workflow_context={
                    "workflow_session_id": self._workflow_session_id,
                    "regulatory_standards": ["GAMP-5"],
                    "hil_resume": True
                }
            )

            # Display categorization results
            print("\n[CATEGORIZATION] HIL-APPROVED RESULTS:")
            print(f"   Category: {self.approved_category}")
            print(f"   Confidence: 100% (Human-approved)")
            print(f"   Source: HIL Consultation")
            flush_output()

            self.logger.info(f"[GAMP5] HIL-approved Category {self.approved_category} with 100% confidence")

            return categorization_event
        # ============================================================
        # END HIL RESUME SECTION
        # ============================================================

        self.logger.info(f"[GAMP5] Starting GAMP-5 categorization for {ev.document_name}")
        flush_output()

        # Log state transition to categorization
        audit_trail.log_state_transition(
            from_state="document_loaded",
            to_state="categorization_starting",
            transition_trigger="urs_ingestion_event",
            transition_metadata={
                "document_name": ev.document_name,
                "document_version": ev.document_version,
                "author": ev.author,
                "content_length": len(ev.urs_content),
                "categorization_workflow": "GAMPCategorizationWorkflow"
            },
            workflow_step="categorize_document",
            state_data={
                "current_step": "gamp_categorization",
                "document_metadata": {
                    "name": ev.document_name,
                    "version": ev.document_version,
                    "author": ev.author
                }
            },
            workflow_context={
                "workflow_session_id": self._workflow_session_id,
                "regulatory_standards": ["GAMP-5"],
                "categorization_purpose": "validation_approach_determination"
            }
        )

        # Initialize categorization workflow
        categorization_workflow = GAMPCategorizationWorkflow(
            verbose=self.verbose
        )

        # Execute categorization
        categorization_result = await categorization_workflow.run(
            urs_content=ev.urs_content,
            document_name=ev.document_name,
            document_version=ev.document_version,
            author=ev.author
        )

        # Handle different result formats
        if hasattr(categorization_result, "result"):
            categorization_data = categorization_result.result
        elif isinstance(categorization_result, dict) and "categorization_event" in categorization_result:
            # Extract the GAMPCategorizationEvent from the dict
            categorization_data = categorization_result["categorization_event"]
        else:
            categorization_data = categorization_result

        # Store categorization results using safe operations
        await safe_context_set(ctx, "categorization_result", categorization_data)

        # If we already have a GAMPCategorizationEvent, use it directly
        if isinstance(categorization_data, GAMPCategorizationEvent):
            categorization_event = categorization_data
            await safe_context_set(ctx, "gamp_category", categorization_data.gamp_category)
            # Display categorization results
            print("\n[CATEGORIZATION] CATEGORIZATION RESULTS:")
            print(f"   Category: {categorization_data.gamp_category.value}")
            print(f"   Confidence: {categorization_data.confidence_score:.2%}")
            flush_output()
            self.logger.info(f"[GAMP5] Category {categorization_data.gamp_category.value} with confidence {categorization_data.confidence_score:.2%}")
        # Handle dict or other formats
        elif isinstance(categorization_data, dict):
            await safe_context_set(ctx, "gamp_category", categorization_data.get("gamp_category"))
            categorization_event = GAMPCategorizationEvent(
                gamp_category=categorization_data.get("gamp_category"),
                confidence_score=categorization_data.get("confidence_score"),
                risk_assessment=categorization_data.get("risk_assessment"),
                document_content=categorization_data.get("document_content", ev.urs_content),
                session_id=self._workflow_session_id
            )
            gamp_cat = categorization_data.get("gamp_category")
            conf_score = categorization_data.get("confidence_score", 0.0)
            # Display categorization results
            print("\n[CATEGORIZATION] CATEGORIZATION RESULTS:")
            print(f"   Category: {gamp_cat}")
            print(f"   Confidence: {conf_score:.2%}")
            flush_output()
            self.logger.info(f"[GAMP5] Category {gamp_cat} with confidence {conf_score:.2%}")
        else:
            await safe_context_set(ctx, "gamp_category", categorization_data.gamp_category)
            categorization_event = GAMPCategorizationEvent(
                gamp_category=categorization_data.gamp_category,
                confidence_score=categorization_data.confidence_score,
                risk_assessment=categorization_data.risk_assessment,
                document_content=categorization_data.document_content,
                session_id=self._workflow_session_id
            )
            self.logger.info(f"[GAMP5] GAMP-5 Category: {categorization_data.gamp_category.value}")

        # Store categorization data for deferred signature creation
        # Signature will be created after consultation/planning flow
        await safe_context_set(ctx, "categorization_for_signature", {
            "categorization_event": categorization_event,
            "document_info": {
                "name": Path(ev.file_path).name if hasattr(ev, "file_path") else
                        (str(ev.urs_content)[:50] if hasattr(ev, "urs_content") and ev.urs_content else "document")
            }
        })

        self.logger.info("[SIGNATURE] Categorization signature deferred until after consultation/planning")

        # Add ALCOA+ record for categorization with enhanced metadata
        try:
            import os
            import platform
            import sys

            alcoa_validator = ALCOAPlusValidator()
            alcoa_record = alcoa_validator.create_data_record(
                data={
                    "action": "gamp_categorization",
                    "category": categorization_event.gamp_category.value if hasattr(categorization_event.gamp_category, "value") else str(categorization_event.gamp_category),
                    "confidence": categorization_event.confidence_score,
                    "risk_assessment": categorization_event.risk_assessment,
                    "regulatory_basis": "GAMP-5",
                    "compliance_standards": ["GAMP-5", "21 CFR Part 11", "ALCOA+"],
                    "document_name": getattr(ev, "document_name", "Unknown"),
                    "categorization_rationale": categorization_event.risk_assessment.get("rationale", ""),
                    "system_type": categorization_event.risk_assessment.get("system_type", ""),
                    "timestamp": datetime.now(UTC).isoformat()
                },
                user_id=getattr(config, "user_name", "System"),
                agent_name="categorization_agent",
                activity="gamp_categorization",
                metadata={
                    "workflow_id": str(self.workflow_id),
                    "document_id": getattr(ev, "document_name", "Unknown"),
                    "confidence_score": categorization_event.confidence_score,
                    "risk_level": categorization_event.risk_assessment.get("risk_level", "Unknown"),
                    "risk_factors": categorization_event.risk_assessment.get("risk_factors", []),
                    "mitigation_required": categorization_event.risk_assessment.get("mitigation_required", False),
                    # System context for traceability
                    "python_version": sys.version.split()[0],
                    "platform": platform.system(),
                    "hostname": platform.node(),
                    "environment": os.environ.get("VALIDATION_MODE", "production"),
                    "timestamp": datetime.now(UTC).isoformat()
                }
            )
            self.logger.info(f"[ALCOA+] Created categorization record with hash: {alcoa_record.get('data_hash', 'N/A')[:8]}...")
        except Exception as e:
            self.logger.warning(f"[ALCOA+] Failed to create categorization record: {e}")

        return categorization_event

    @step
    async def run_planning_workflow(
        self,
        ctx: Context,
        ev: PlanningEvent
    ) -> AgentRequestEvent | AgentResultsEvent:
        """
        Execute parallel agent coordination based on planning results.
        
        Args:
            ctx: Workflow context
            ev: Planning event with test strategy and requirements
            
        Returns:
            AgentRequestEvent for next agent to execute, or AgentResultsEvent if no coordination needed
        """
        self.logger.info("[PARALLEL] Starting parallel agent coordination from planning event")
        flush_output()

        # Store the planning event in context using safe operations
        await safe_context_set(ctx, "planning_event", ev)
        await safe_context_set(ctx, "test_strategy", ev.test_strategy)

        # Validate critical state was properly stored for GAMP-5 compliance
        await validate_workflow_state(ctx, ["planning_event", "test_strategy"])

        # Log successful state storage for audit trail
        await log_state_operation("store", "planning_event", True)

        # Generate proper agent requests based on GAMP category
        agent_requests = []
        if self.enable_parallel_coordination:
            # Always include context provider
            agent_requests.append({
                "agent_type": "context_provider",
                "request_data": {
                    "gamp_category": str(ev.gamp_category.value),  # CRITICAL FIX: Explicit string conversion
                    "test_strategy": ev.test_strategy,
                    "document_sections": ["functional_requirements", "validation_requirements"],
                    "search_scope": {}  # Add required field for ContextProviderRequest
                },
                "correlation_id": f"ctx_{self._workflow_session_id}"
            })

            # Add research agent for regulatory updates
            agent_requests.append({
                "agent_type": "research",
                "request_data": {
                    "research_focus": ["GAMP-5", f"Category {ev.gamp_category.value}", "OQ testing"],
                    "regulatory_scope": ["FDA", "EMA", "ICH"]
                },
                "correlation_id": f"res_{self._workflow_session_id}"
            })

            # Add SME agent for category-specific expertise
            agent_requests.append({
                "agent_type": "sme",
                "request_data": {
                    "specialty": f"GAMP Category {ev.gamp_category.value}",
                    "test_focus": "OQ testing for pharmaceutical compliance",
                    "compliance_level": "high",
                    "validation_focus": [ev.test_strategy.get("validation_rigor", "standard")]  # List format
                },
                "correlation_id": f"sme_{self._workflow_session_id}"
            })

        # Store agent requests separately using safe operations
        await safe_context_set(ctx, "agent_requests", agent_requests)

        self.logger.info(
            f"[PLANNING] Planning processed - {ev.estimated_test_count} tests estimated, "
            f"{len(agent_requests)} agents to coordinate"
        )

        if not self.enable_parallel_coordination or not agent_requests:
            self.logger.info("[PARALLEL] Skipping parallel coordination - creating empty results")
            # Create empty agent results to proceed to OQ generation
            return AgentResultsEvent(
                agent_results=[],
                session_id=self._workflow_session_id
            )

        # Convert planning requests to agent request events
        agent_request_events = []
        for i, request in enumerate(agent_requests):
            agent_request = AgentRequestEvent(
                agent_type=request.get("agent_type", "unknown"),
                request_data=request.get("request_data", {}),
                correlation_id=uuid4(),  # Generate proper UUID
                requesting_step="run_planning_workflow",
                session_id=self._workflow_session_id
            )
            agent_request_events.append(agent_request)

        # Store coordination context using safe operations
        await safe_context_set(ctx, "coordination_requests", agent_request_events)
        await safe_context_set(ctx, "expected_results_count", len(agent_request_events))
        await safe_context_set(ctx, "current_request_index", 0)
        await safe_context_set(ctx, "collected_results", [])  # Initialize collected results

        # Emit the first request
        if agent_request_events:
            return agent_request_events[0]
        # No requests to process - return empty results
        return AgentResultsEvent(
            agent_results=[],
            session_id=self._workflow_session_id
        )


    @step(num_workers=3)  # Allow parallel processing
    async def execute_agent_request(
        self,
        ctx: Context,
        ev: AgentRequestEvent
    ) -> AgentResultEvent:
        """
        Execute individual agent requests in parallel.
        
        Args:
            ctx: Workflow context
            ev: Agent request event
            
        Returns:
            AgentResultEvent with agent execution results
        """
        import time
        start_time = time.time()
        self.logger.info(f"[AGENT] Executing {ev.agent_type} agent request")
        flush_output()

        try:
            # Import asyncio for timeout protection

            # Dynamic timeout configuration based on agent type and operation
            timeout_mapping = {
                "research": 300.0,           # 5 minutes for regulatory APIs (FDA can take 14+ seconds)
                "sme": 300.0,               # 5 minutes for DeepSeek V3 LLM calls (increased from 120s)
                "context_provider": 60.0,   # 1 minute for document processing
            }

            agent_timeout = timeout_mapping.get(ev.agent_type.lower(), 60.0)  # Default 1 minute

            self.logger.info(f"[AGENT] Starting {ev.agent_type} agent with {agent_timeout}s timeout")
            flush_output()

            # Execute actual agents based on type with timeout protection
            if ev.agent_type.lower() == "context_provider":
                # Use the actual context provider agent
                from src.agents.parallel.context_provider import (
                    create_context_provider_agent,
                )

                agent = create_context_provider_agent(
                    verbose=self.verbose,
                    enable_phoenix=self.enable_phoenix,
                    max_documents=10
                )

                # Process the request with timeout and progress indicators
                try:
                    result_event = await show_progress_during_wait(
                        agent.process_request(ev),
                        timeout=agent_timeout,
                        operation_name="Context Processing",
                        agent_type=ev.agent_type
                    )
                except TimeoutError:
                    timeout_msg = f"CRITICAL: {ev.agent_type} agent timed out after {agent_timeout} seconds. This prevents OQ generation from starting."
                    self.tracer.log_error(f"{ev.agent_type}_timeout", Exception(timeout_msg))
                    self.logger.error(f"[TIMEOUT] {timeout_msg}")
                    self.logger.error(f"[TIMEOUT] Agent type: {ev.agent_type}, Request data: {ev.request_data}")
                    self.logger.error("[TIMEOUT] Workflow will not proceed to OQ generation due to agent failure.")
                    flush_output()
                    return AgentResultEvent(
                        agent_type=ev.agent_type,
                        correlation_id=ev.correlation_id,
                        result_data={
                            "error": f"Agent execution timed out after {agent_timeout} seconds",
                            "error_type": "TimeoutError"
                        },
                        success=False,
                        session_id=self._workflow_session_id,
                        processing_time=agent_timeout
                    )

                # Return the result event with session ID
                result_event.session_id = self._workflow_session_id
                processing_time = time.time() - start_time
                self.logger.info(f"[AGENT] {ev.agent_type} agent completed successfully in {processing_time:.2f}s (timeout was {agent_timeout}s)")
                flush_output()
                return result_event

            if ev.agent_type.lower() == "sme":
                # Use the actual SME agent
                from src.agents.parallel.sme_agent import create_sme_agent

                agent = create_sme_agent(
                    specialty=ev.request_data.get("specialty", "general_validation"),
                    verbose=self.verbose
                )

                # Process the request with timeout and progress indicators
                try:
                    result_event = await show_progress_during_wait(
                        agent.process_request(ev),
                        timeout=agent_timeout,
                        operation_name="SME Analysis",
                        agent_type=ev.agent_type
                    )
                except TimeoutError:
                    timeout_msg = f"CRITICAL: {ev.agent_type} agent timed out after {agent_timeout} seconds. This prevents OQ generation from starting."
                    self.tracer.log_error(f"{ev.agent_type}_timeout", Exception(timeout_msg))
                    self.logger.error(f"[TIMEOUT] {timeout_msg}")
                    self.logger.error(f"[TIMEOUT] Agent type: {ev.agent_type}, Request data: {ev.request_data}")
                    self.logger.error("[TIMEOUT] Workflow will not proceed to OQ generation due to agent failure.")
                    flush_output()
                    return AgentResultEvent(
                        agent_type=ev.agent_type,
                        correlation_id=ev.correlation_id,
                        result_data={
                            "error": f"Agent execution timed out after {agent_timeout} seconds",
                            "error_type": "TimeoutError"
                        },
                        success=False,
                        session_id=self._workflow_session_id,
                        processing_time=agent_timeout
                    )

                # Return the result event with session ID
                result_event.session_id = self._workflow_session_id
                processing_time = time.time() - start_time
                self.logger.info(f"[AGENT] {ev.agent_type} agent completed successfully in {processing_time:.2f}s (timeout was {agent_timeout}s)")
                flush_output()
                return result_event

            if ev.agent_type.lower() == "research":
                # Use cached research agent to prevent resource leaks
                if self._cached_research_agent is None:
                    from src.agents.parallel.research_agent import create_research_agent
                    self._cached_research_agent = create_research_agent(
                        verbose=self.verbose
                    )
                    self.logger.debug(f"[AGENTS] Created cached research agent: {id(self._cached_research_agent)}")
                else:
                    self.logger.debug(f"[AGENTS] Reusing cached research agent: {id(self._cached_research_agent)}")

                agent = self._cached_research_agent

                # Process the request with timeout and progress indicators
                try:
                    result_event = await show_progress_during_wait(
                        agent.process_request(ev),
                        timeout=agent_timeout,
                        operation_name="Research & Regulatory Updates",
                        agent_type=ev.agent_type
                    )
                except TimeoutError:
                    timeout_msg = f"CRITICAL: {ev.agent_type} agent timed out after {agent_timeout} seconds. This prevents OQ generation from starting."
                    self.tracer.log_error(f"{ev.agent_type}_timeout", Exception(timeout_msg))
                    self.logger.error(f"[TIMEOUT] {timeout_msg}")
                    self.logger.error(f"[TIMEOUT] Agent type: {ev.agent_type}, Request data: {ev.request_data}")
                    self.logger.error("[TIMEOUT] Workflow will not proceed to OQ generation due to agent failure.")
                    flush_output()
                    return AgentResultEvent(
                        agent_type=ev.agent_type,
                        correlation_id=ev.correlation_id,
                        result_data={
                            "error": f"Agent execution timed out after {agent_timeout} seconds",
                            "error_type": "TimeoutError"
                        },
                        success=False,
                        session_id=self._workflow_session_id,
                        processing_time=agent_timeout
                    )

                # Return the result event with session ID
                result_event.session_id = self._workflow_session_id
                processing_time = time.time() - start_time
                self.logger.info(f"[AGENT] {ev.agent_type} agent completed successfully in {processing_time:.2f}s (timeout was {agent_timeout}s)")
                flush_output()
                return result_event

            # Unknown agent type
            self.logger.warning(f"Unknown agent type: {ev.agent_type}")
            return AgentResultEvent(
                agent_type=ev.agent_type,
                correlation_id=ev.correlation_id,
                result_data={
                    "error": f"Unknown agent type: {ev.agent_type}",
                    "supported_types": ["context_provider", "sme", "research"]
                },
                success=False,
                session_id=self._workflow_session_id,
                processing_time=0.0
            )

        except Exception as e:
            self.logger.error(f"[ERROR] Agent {ev.agent_type} execution failed: {e}")
            return AgentResultEvent(
                agent_type=ev.agent_type,
                correlation_id=ev.correlation_id,
                result_data={
                    "error": str(e),
                    "error_type": type(e).__name__,
                    "agent_type": ev.agent_type
                },
                success=False,
                session_id=self._workflow_session_id,
                processing_time=0.0
            )

    @step
    async def collect_agent_results(
        self,
        ctx: Context,
        ev: AgentResultEvent
    ) -> AgentRequestEvent | AgentResultsEvent | None:
        """
        Collect agent results and emit next request or final results.
        
        Args:
            ctx: Workflow context
            ev: Agent result event
            
        Returns:
            Next AgentRequestEvent, AgentResultsEvent when all results collected, or None while waiting
        """
        # Store the result using safe operations
        results = await safe_context_get(ctx, "collected_results", [])
        results.append(ev)
        await safe_context_set(ctx, "collected_results", results)

        # Get coordination context using safe retrieval
        coordination_requests = await safe_context_get(ctx, "coordination_requests", [])
        current_index = await safe_context_get(ctx, "current_request_index", 0)

        # Check if we have more requests to emit
        next_index = current_index + 1
        if next_index < len(coordination_requests):
            # Emit the next request using safe context operations
            await safe_context_set(ctx, "current_request_index", next_index)
            self.logger.info(f"[PARALLEL] Emitting agent request {next_index + 1}/{len(coordination_requests)}")
            return coordination_requests[next_index]

        # All requests have been processed, check if we have all results
        expected_count = await safe_context_get(ctx, "expected_results_count", 0)
        if len(results) >= expected_count:
            self.logger.info(f"[RESULTS] Collected all {len(results)} agent results")
            return AgentResultsEvent(
                agent_results=results,
                session_id=self._workflow_session_id
            )

        # Still waiting for results
        return None

    # DISABLED: This step was causing orphaned OQTestGenerationEvent
    # The generate_oq_tests step already handles AgentResultsEvent correctly

    @step
    async def check_consultation_required(
        self,
        ctx: Context,
        ev: GAMPCategorizationEvent
    ) -> ConsultationRequiredEvent | ConsultationBypassedEvent | PlanningEvent:
        """
        Check if human consultation is required based on categorization results.
        
        Implements validation mode bypass logic: when validation_mode=True,
        consultations that would normally be required are bypassed with
        full audit trail logging for regulatory compliance.
        
        Args:
            ctx: Workflow context
            ev: GAMP categorization event
            
        Returns:
            ConsultationRequiredEvent if consultation needed (production mode),
            ConsultationBypassedEvent if bypassed (validation mode),
            or PlanningEvent if no consultation needed
        """
        # Store categorization result in context using safe operations
        await safe_context_set(ctx, "categorization_result", ev)
        await safe_context_set(ctx, "gamp_category", ev.gamp_category)

        # Get validation mode configuration
        validation_mode_enabled = config.validation_mode.validation_mode
        bypass_threshold = config.validation_mode.bypass_consultation_threshold
        bypass_allowed_categories = config.validation_mode.bypass_allowed_categories

        if not self.enable_human_consultation:
            # Skip consultation - create planning event directly
            self.logger.info("Skipping consultation check - creating planning event")
            return self._create_planning_event_from_categorization(ev)

        # Check if consultation is required
        # CRITICAL FIX: Check original confidence for SME-recovered categorizations
        # If categorization initially failed but was recovered by SME consultation,
        # we must still trigger human consultation based on the ORIGINAL failure
        risk_assessment = ev.risk_assessment or {}

        requires_consultation, consultation_triggers, confidence_for_consultation = derive_consultation_triggers(
            ev,
            bypass_threshold
        )

        if "original_confidence" in risk_assessment and confidence_for_consultation != ev.confidence_score:
            self.logger.warning(
                f"[AUDIT TRAIL] SME consultation recovery detected - using original confidence "
                f"{confidence_for_consultation:.2f} for consultation decision (recovered to {ev.confidence_score:.2f})"
            )

        if requires_consultation:
            # Create the consultation event that would be required
            # Include both original and current confidence for full transparency
            if consultation_triggers:
                reason_text = f"Category {ev.gamp_category.value}: " + "; ".join(consultation_triggers)
            else:
                reason_text = f"Category {ev.gamp_category.value} with confidence {ev.confidence_score:.2f}"
                if "original_confidence" in risk_assessment:
                    reason_text = (
                        f"Category {ev.gamp_category.value} - Original confidence {confidence_for_consultation:.2f}, "
                        f"recovered to {ev.confidence_score:.2f} via SME consultation"
                    )

            consultation_event = ConsultationRequiredEvent(
                consultation_type="categorization_review",
                context={
                    "reason": reason_text,
                    "gamp_category": ev.gamp_category,
                    "confidence_score": ev.confidence_score,
                    "original_confidence": confidence_for_consultation,  # Always include the confidence used for decision
                    "sme_recovery": "original_confidence" in risk_assessment,
                    "risk_assessment": ev.risk_assessment,
                    "session_id": self._workflow_session_id,
                    "consultation_triggers": consultation_triggers,
                    "review_required": ev.review_required,
                    "has_ambiguity_signals": getattr(ev, "has_ambiguity_signals", False),
                    "ambiguity_details": getattr(ev, "ambiguity_details", None),
                    "alternative_categories": getattr(ev, "alternative_categories", None),
                    "confidence_threshold": bypass_threshold
                },
                urgency="normal",
                required_expertise=["validation_engineer", "quality_assurance"],
                triggering_step="check_consultation_required"
            )

            # Check if we should bypass consultation due to validation mode
            should_bypass = (
                validation_mode_enabled and
                ev.gamp_category.value in bypass_allowed_categories
            )

            if should_bypass:
                self.logger.info(
                    f"[VALIDATION MODE] Bypassing consultation for Category {ev.gamp_category.value} "
                    f"(confidence: {ev.confidence_score:.2f}) - validation mode active"
                )

                # Create bypass event for audit trail
                bypass_event = ConsultationBypassedEvent(
                    original_consultation=consultation_event,
                    bypass_reason="validation_mode_enabled",
                    quality_metrics={
                        "original_confidence": ev.confidence_score,
                        "gamp_category": ev.gamp_category.value,
                        "bypass_threshold": bypass_threshold,
                        "validation_mode_active": True,
                        "consultation_triggers": consultation_triggers
                    }
                )

                # Log bypass for audit trail
                self.logger.warning(
                    f"AUDIT TRAIL: Consultation bypassed for {consultation_event.consultation_id} "
                    f"due to validation mode. Original consultation: {consultation_event.consultation_type}"
                )

                # Store categorization event in bypass event for downstream processing
                bypass_event.original_consultation.categorization_event = ev

                # Return bypass event - it will be consumed by handle_consultation_bypassed step
                return bypass_event
            # Production mode or category not allowed for bypass - require consultation
            self.logger.info("[CONSULT] Human consultation required - production mode or bypass not allowed")
            consultation_event.categorization_event = ev  # Add as dynamic attribute
            return consultation_event

        # No consultation needed - create planning event directly
        self.logger.info("No consultation required - creating planning event")
        return self._create_planning_event_from_categorization(ev)

    @step
    async def handle_consultation_bypassed(
        self,
        ctx: Context,
        ev: ConsultationBypassedEvent
    ) -> PlanningEvent:
        """
        Handle consultation bypass events for validation mode.
        
        This step processes ConsultationBypassedEvent by logging the bypass
        for audit trail and continuing with workflow execution.
        
        Args:
            ctx: Workflow context
            ev: Consultation bypassed event
            
        Returns:
            PlanningEvent to continue workflow execution
        """
        self.logger.info(f"[VALIDATION MODE] Processing consultation bypass: {ev.consultation_id}")

        # Log bypass metrics for audit trail
        bypass_metrics = {
            "consultation_type": ev.consultation_type,
            "gamp_category": ev.gamp_category,
            "confidence_score": ev.confidence_score,
            "bypass_timestamp": ev.bypass_timestamp,
            "bypass_reason": ev.bypass_reason
        }

        # Store bypass information in context for audit trail
        await safe_context_set(ctx, "consultation_bypassed", True)
        await safe_context_set(ctx, "bypass_metrics", bypass_metrics)

        # Get the original categorization from the bypass event context
        if ev.original_consultation and hasattr(ev.original_consultation, "categorization_event"):
            categorization_event = ev.original_consultation.categorization_event
        else:
            # Reconstruct from bypass event data
            from src.core.events import GAMPCategorizationEvent, GAMPCategory
            categorization_event = GAMPCategorizationEvent(
                gamp_category=GAMPCategory(ev.gamp_category) if ev.gamp_category else GAMPCategory.CATEGORY_5,
                confidence_score=ev.confidence_score or 0.6,
                justification="Reconstructed from bypass event for workflow continuation",
                risk_assessment={"bypassed_consultation": True},
                categorized_by="validation_mode_bypass"
            )

        # Create planning event to continue workflow
        planning_event = self._create_planning_event_from_categorization(categorization_event)

        self.logger.info("[VALIDATION MODE] Consultation bypass processed - continuing with planning")
        return planning_event

    def _create_planning_event_from_categorization(self, categorization_event: GAMPCategorizationEvent) -> PlanningEvent:
        """
        Create a planning event from categorization results.
        
        Args:
            categorization_event: GAMP categorization event
            
        Returns:
            PlanningEvent with test strategy and requirements
        """
        # Get test types and compliance requirements based on category
        test_types_map = {
            1: ["installation", "configuration"],
            3: ["installation", "configuration", "functional"],
            4: ["installation", "configuration", "functional", "performance"],
            5: ["installation", "configuration", "functional", "performance", "integration"]
        }

        compliance_map = {
            1: ["GAMP-5"],
            3: ["GAMP-5", "ALCOA+"],
            4: ["GAMP-5", "ALCOA+", "21 CFR Part 11"],
            5: ["GAMP-5", "ALCOA+", "21 CFR Part 11", "CSV"]
        }

        # Create default test strategy based on GAMP category
        test_strategy = {
            "approach": "category_based",
            "category": categorization_event.gamp_category.value,
            "validation_rigor": "standard" if categorization_event.gamp_category.value <= 3 else "enhanced",
            "confidence_score": categorization_event.confidence_score
        }

        return PlanningEvent(
            test_strategy=test_strategy,
            required_test_types=test_types_map.get(categorization_event.gamp_category.value, ["basic"]),
            compliance_requirements=compliance_map.get(categorization_event.gamp_category.value, ["GAMP-5"]),
            estimated_test_count=min(6, 3 + categorization_event.gamp_category.value),  # PERFORMANCE FIX: Reduced from 5 + (category * 2) to max 6 tests
            planner_agent_id=f"planner_{self._workflow_session_id}",
            gamp_category=categorization_event.gamp_category
        )

    @step
    async def handle_consultation(
        self,
        ctx: Context,
        ev: ConsultationRequiredEvent
    ) -> PlanningEvent:
        """
        Handle human consultation requirements using event-driven pattern.
        
        This step no longer blocks the terminal with input() calls. Instead,
        it uses the event-driven consultation system to collect human input
        without interfering with the LlamaIndex workflow execution.
        
        Args:
            ctx: Workflow context
            ev: Consultation required event
            
        Returns:
            PlanningEvent to continue workflow after consultation
        """
        self.logger.info(f"[CONSULT] Processing consultation: {ev.context.get('reason', 'Unknown reason')}")

        # Get consultation context from categorization results
        context = ev.context
        reason = context.get("reason", "Low confidence categorization")
        suggested_category = context.get("gamp_category", None)
        confidence_score = context.get("confidence_score", 0.0)

        # Create consultation input event with complete context
        consultation_prompt = self._build_consultation_prompt(reason, suggested_category, confidence_score)

        consultation_input_event = ConsultationInputEvent(
            consultation_context=context,
            prompt_text=consultation_prompt,
            timeout_seconds=300,  # 5 minute timeout
            consultation_type="gamp_categorization",
            urgency="high"  # Low confidence requires immediate attention
        )

        self.logger.info(f"[CONSULT] Requesting human input for consultation {consultation_input_event.consultation_id}")

        try:
            # Process consultation using external handler (non-blocking)
            human_response = await process_consultation_input(consultation_input_event)

            self.logger.info(f"[CONSULT] Received human response from {human_response.user_id}")

            # Extract consultation results from human response
            response_data = human_response.response_data
            approved_category = response_data["gamp_category"]
            justification = response_data["category_justification"]

            # Create comprehensive consultation result for audit trail
            consultation_result = {
                "consultation_reason": reason,
                "consultation_timestamp": human_response.timestamp.isoformat(),
                "consultation_status": "human_approved",
                "approved_category": approved_category,
                "original_confidence": confidence_score,
                "original_suggestion": suggested_category,
                "operator_name": human_response.user_id,
                "operator_role": human_response.user_role,
                "decision_rationale": human_response.decision_rationale,
                "digital_signature": human_response.digital_signature,
                "consultation_id": str(consultation_input_event.consultation_id),
                "regulatory_impact": human_response.regulatory_impact,
                "confidence_level": human_response.confidence_level,
                "method": "event_driven_consultation"
            }

            await safe_context_set(ctx, "consultation_result", consultation_result)

            # Create new categorization event using human-approved category
            gamp_category = GAMPCategory(approved_category)

            # Create a categorization event with human-approved results
            categorization_event = GAMPCategorizationEvent(
                gamp_category=gamp_category,
                confidence_score=1.0,  # Human decisions have full confidence
                justification=f"Human-approved categorization: Category {approved_category} - {justification}",
                risk_assessment={
                    "consultation_completed": True,
                    "human_approved": True,
                    "method": "event_driven_consultation",
                    "approval_status": "human_approved",
                    "operator": human_response.user_id,
                    "operator_role": human_response.user_role
                },
                review_required=False,  # No further review needed after human approval
                categorized_by=f"human_consultation_{human_response.user_id}"
            )

            # CRITICAL FIX: Update context with human-corrected categorization
            # This ensures downstream steps use the human-approved category
            await safe_context_set(ctx, "categorization_result", categorization_event)

            # CRITICAL FIX: Store with key that signature step expects
            # Signature step retrieves "categorization_for_signature" (line 1662)
            await safe_context_set(ctx, "categorization_for_signature", {
                "categorization_event": categorization_event,
                "document_info": {
                    "name": Path(self.document_path).name if hasattr(self, "document_path") and self.document_path else "Unknown",
                    "path": self.document_path if hasattr(self, "document_path") else ""
                }
            })

            return self._create_planning_event_from_categorization(categorization_event)

        except HumanApprovalRequired:
            # Re-raise HumanApprovalRequired for worker to catch and set AWAITING_APPROVAL status
            self.logger.info("[CONSULT] HumanApprovalRequired raised - workflow suspended for async web approval")
            raise

        except Exception as e:
            self.logger.error(f"[CONSULT] Consultation failed: {e!s}")
            # NO FALLBACKS - Surface error explicitly
            raise RuntimeError(f"Human consultation failed: {e!s}. No fallback available - human input required.")

    def _build_consultation_prompt(self, reason: str, suggested_category, confidence_score: float) -> str:
        """Build consultation prompt text for display."""
        prompt_lines = [
            f"Reason: {reason}",
            f"AI Confidence: {confidence_score:.2%}"
        ]

        if suggested_category:
            if hasattr(suggested_category, "value"):
                suggested_category = suggested_category.value
            prompt_lines.append(f"AI Suggestion: Category {suggested_category}")

        prompt_lines.extend([
            "",
            "⚠️  Low confidence detected - human expertise required",
            "",
            "Please select the appropriate GAMP-5 category for this software component."
        ])

        return "\n".join(prompt_lines)

    @step
    async def create_categorization_signature(
        self,
        ctx: Context,
        ev: AgentResultsEvent
    ) -> SignedAgentResultsEvent:
        """
        Create electronic signature for categorization after consultation/planning is complete.
        
        This step ensures that human consultation decisions are properly captured
        in electronic signatures for 21 CFR Part 11 compliance.
        
        Args:
            ctx: Workflow context
            ev: Agent results event (passed through)
            
        Returns:
            SignedAgentResultsEvent to continue workflow with signature metadata
        """
        self.logger.info("[SIGNATURE] Creating deferred categorization signature")

        # Get deferred categorization data
        categorization_data = await safe_context_get(ctx, "categorization_for_signature", None)
        if not categorization_data:
            self.logger.warning("[SIGNATURE] No categorization data found for signature - skipping")
            return SignedAgentResultsEvent(
                agent_results=ev.agent_results,
                session_id=ev.session_id,
                total_execution_time=ev.total_execution_time,
                signature_created=False
            )

        config = get_config()
        if not (self.enable_part11_compliance and self.signature_service and not config.validation_mode.validation_mode):
            self.logger.info("[SIGNATURE] Part 11 compliance disabled or validation mode - skipping signature")
            return SignedAgentResultsEvent(
                agent_results=ev.agent_results,
                session_id=ev.session_id,
                total_execution_time=ev.total_execution_time,
                signature_created=False
            )

        try:
            categorization_event = categorization_data["categorization_event"]
            doc_name = categorization_data["document_info"]["name"]

            # Check for human consultation data in context
            consultation_result = await safe_context_get(ctx, "consultation_result", None)

            if consultation_result is None:
                # No consultation required - typically Category 3 (non-configured products)
                self.logger.info(
                    "[SIGNATURE] No consultation required for Category 3 (non-configured product). "
                    "Skipping consultation result processing."
                )

            if consultation_result:
                # Human consultation occurred - use human operator data for signature
                operator_name = consultation_result["operator_name"]
                operator_role = consultation_result["operator_role"].replace("_", " ").title()
                signer_name = f"{operator_name} ({operator_role})"
                signer_id = operator_name

                # Extract employee ID from digital signature format: "Name_ID_Timestamp"
                employee_id = "unknown"
                digital_sig = consultation_result.get("digital_signature", "")
                if "_" in digital_sig:
                    try:
                        parts = digital_sig.split("_")
                        if len(parts) >= 2:
                            employee_id = parts[1]  # Extract ID portion
                    except Exception:
                        employee_id = "unknown"  # Fallback if parsing fails

                additional_context = {
                    "workflow_session": self._workflow_session_id,
                    "risk_assessment": categorization_event.risk_assessment,
                    "consultation_required": True,
                    "employee_id": employee_id,
                    "operator_role": consultation_result["operator_role"],
                    "decision_justification": consultation_result["decision_rationale"],
                    "original_ai_confidence": consultation_result.get("original_confidence", 0.0),
                    "human_selected_category": consultation_result["approved_category"],
                    "consultation_method": consultation_result.get("method", "event_driven_consultation"),
                    "regulatory_impact": consultation_result.get("regulatory_impact", "high")
                }

                self.logger.info(
                    f"[SIGNATURE] Human consultation completed - signing as {signer_name} "
                    f"(Category {consultation_result['approved_category']}, Employee ID: {employee_id})"
                )
            else:
                # Automated decision - use system defaults (Category 3 path)
                signer_name = getattr(config, "user_name", "System")
                signer_id = getattr(config, "user_id", "system")
                additional_context = {
                    "workflow_session": self._workflow_session_id,
                    "risk_assessment": categorization_event.risk_assessment,
                    "consultation_required": False,
                    # CRITICAL FIX: Include GAMP category for Category 3 (automated path)
                    # Without this, metadata validation fails with "GAMP category = None"
                    "gamp_category": categorization_event.gamp_category.value,
                    "confidence_score": categorization_event.confidence_score
                }

                self.logger.info(
                    f"[SIGNATURE] Automated categorization - signing as System "
                    f"(Category {categorization_event.gamp_category.value}, "
                    f"Confidence: {categorization_event.confidence_score:.2%})"
                )

            signature_binding = self.signature_service.bind_signature_to_record(
                record_id=f"cat_{self._workflow_session_id}",
                record_content={
                    "action": "gamp_categorization",
                    "category": categorization_event.gamp_category.value if hasattr(categorization_event.gamp_category, "value") else str(categorization_event.gamp_category),
                    "confidence": categorization_event.confidence_score,
                    "document": doc_name,
                    "timestamp": datetime.now(UTC).isoformat()
                },
                signer_name=signer_name,
                signer_id=signer_id,
                signature_meaning=SignatureMeaning.REVIEWED,
                additional_context=additional_context
            )

            self.logger.info(f"[SIGNATURE] Categorization signed: {signature_binding.signature_id}")

            # Return signed event with signature metadata
            return SignedAgentResultsEvent(
                agent_results=ev.agent_results,
                session_id=ev.session_id,
                total_execution_time=ev.total_execution_time,
                signature_id=signature_binding.signature_id,
                signature_created=True
            )

        except Exception as sig_e:
            self.logger.warning(f"[SIGNATURE] Electronic signature failed for categorization: {sig_e}")
            # Continue without signature in case of error
            return SignedAgentResultsEvent(
                agent_results=ev.agent_results,
                session_id=ev.session_id,
                total_execution_time=ev.total_execution_time,
                signature_created=False
            )

    @step
    async def generate_oq_tests(
        self,
        ctx: Context,
        ev: SignedAgentResultsEvent
    ) -> OQTestSuiteEvent:
        """
        Generate OQ test suite based on planning and agent results.
        
        Args:
            ctx: Workflow context
            ev: Signed agent results event with context data and signature metadata
            
        Returns:
            OQTestSuiteEvent with generated test suite
        """
        self.logger.info("[OQ] Starting OQ test generation")
        flush_output()

        # Validate critical workflow state exists before proceeding
        await validate_workflow_state(ctx, ["planning_event", "categorization_result"])

        # Get required context using safe retrieval with validation
        planning_event = await safe_context_get(ctx, "planning_event", None)
        categorization_result = await safe_context_get(ctx, "categorization_result", None)
        document_path = await safe_context_get(ctx, "document_path", "unknown")

        # Get document content from various sources
        urs_content = ""
        if categorization_result and hasattr(categorization_result, "document_content"):
            urs_content = categorization_result.document_content
        elif document_path and document_path != "unknown":
            try:
                urs_content = Path(document_path).read_text(encoding="utf-8")
            except Exception:
                urs_content = "Document content not available"
        else:
            urs_content = "Document content not available"

        # Validate required context - fail explicitly if missing critical data
        if planning_event is None:
            raise ValueError("Planning event not found in context - workflow state corrupted")
        if categorization_result is None:
            raise ValueError("Categorization result not found in context - workflow state corrupted")

        # Aggregate context from agent results
        aggregated_context = {
            "agent_results": {}
        }

        for result in ev.agent_results:
            if result.success:
                aggregated_context["agent_results"][result.agent_type] = result.result_data

        # Add planning context
        aggregated_context["planning_context"] = {
            "test_strategy": planning_event.test_strategy,
            "estimated_test_count": planning_event.estimated_test_count
        }

        # Create OQ generation event
        # CRITICAL FIX: Use planning_event.gamp_category which contains human-approved category
        # instead of categorization_result.gamp_category which may contain original AI category
        oq_generation_event = OQTestGenerationEvent(
            gamp_category=planning_event.gamp_category,
            urs_content=urs_content,
            document_metadata={
                "name": Path(document_path).name if document_path else "Unknown",
                "path": document_path,
                "version": "1.0"
            },
            aggregated_context=aggregated_context,
            required_test_count=planning_event.estimated_test_count,
            test_strategy=planning_event.test_strategy,
            correlation_id=uuid4(),
            session_id=self._workflow_session_id
        )

        # Run OQ generation workflow with the event
        try:
            self.logger.info("Creating OQ generation workflow...")
            # NO FALLBACKS: Only pass supported parameters
            oq_workflow = OQGenerationWorkflow(timeout=1500)
            self.logger.info("OQ workflow created successfully")

        except Exception as e:
            self.logger.error(f"Failed to create OQ generation workflow: {e}")
            raise RuntimeError(
                f"OQ workflow instantiation failed: {e}. "
                f"This may indicate parameter passing issues or import problems."
            ) from e

        try:
            self.logger.info("Running OQ test generation workflow with data...")

            event_data = {
                "gamp_category": oq_generation_event.gamp_category.value,
                "urs_content": oq_generation_event.urs_content,
                "document_metadata": oq_generation_event.document_metadata,
                "required_test_count": oq_generation_event.required_test_count,
                "test_strategy": oq_generation_event.test_strategy,
                "agent_results": oq_generation_event.aggregated_context,
                "categorization_confidence": categorization_result.confidence_score,
                "correlation_id": oq_generation_event.correlation_id
            }

            self.logger.info(f"Calling workflow.run() with data keys: {list(event_data.keys())}")

            # CRITICAL FIX: Call workflow with data parameter, not StartEvent
            self.logger.info("About to call OQ workflow.run() - checking before execution")
            oq_result = await oq_workflow.run(data=event_data)
            self.logger.info(f"OQ workflow completed, result type: {type(oq_result)}")

            # CRITICAL DEBUG: Log the actual result content to understand what's being returned
            if hasattr(oq_result, "__dict__"):
                self.logger.info(f"OQ result attributes: {list(oq_result.__dict__.keys())}")
            if hasattr(oq_result, "result"):
                self.logger.info(f"OQ result.result type: {type(oq_result.result)}")
                if hasattr(oq_result.result, "__dict__"):
                    self.logger.info(f"OQ result.result attributes: {list(oq_result.result.__dict__.keys())}")

            # CRITICAL FIX: Check result type first
            if isinstance(oq_result, ConsultationRequiredEvent):
                # Handle consultation event properly
                self.logger.warning(
                    f"OQ generation returned consultation request: {oq_result.consultation_type}"
                )

                # Extract error details
                error_context = oq_result.context
                error_type = error_context.get("consultation_type", "unknown") if error_context else "unknown"

                # Re-raise with proper context
                raise RuntimeError(
                    f"OQ generation requires consultation: {error_type}",
                    {"consultation_event": oq_result, "context": error_context}
                )

            # Handle OQTestSuiteEvent directly
            if isinstance(oq_result, OQTestSuiteEvent):
                self.logger.info(
                    f"[OQ] Generated {oq_result.test_suite.total_test_count} OQ tests successfully"
                )
                return oq_result

            # Handle dictionary result (legacy format)
            if hasattr(oq_result, "result"):
                oq_data = oq_result.result
            else:
                oq_data = oq_result

            # Process dictionary result
            if isinstance(oq_data, dict):
                self.logger.info(f"Processing dictionary result with keys: {list(oq_data.keys())}")
                self.logger.info(f"Dictionary status: {oq_data.get('status', 'NO_STATUS')}")

                if oq_data.get("status") == "completed_successfully":
                    oq_event = oq_data.get("full_event")
                    self.logger.info(f"Full_event type: {type(oq_event)}")

                    if oq_event and isinstance(oq_event, OQTestSuiteEvent):
                        test_count = oq_event.test_suite.total_test_count
                        self.logger.info(f"[OQ] Generated {test_count} OQ tests successfully")

                        # CRITICAL DEBUG: Validate test suite actually has test cases
                        if test_count == 0 or not oq_event.test_suite.test_cases:
                            self.logger.error("CRITICAL: OQ workflow claims success but generated 0 test cases!")
                            self.logger.error(f"Test suite ID: {oq_event.test_suite.suite_id}")
                            self.logger.error(f"Test cases list: {oq_event.test_suite.test_cases}")
                            raise RuntimeError("OQ generation succeeded but produced no test cases - NO FALLBACKS ALLOWED")

                        return oq_event
                    self.logger.error(f"No valid OQTestSuiteEvent in full_event: {oq_event}")

                # Handle consultation in dictionary format
                # The oq_data dict IS the consultation object, not nested under a "consultation" key
                consultation_type = oq_data.get("consultation_type", "unknown")
                consultation_context = oq_data.get("consultation_context", {})
                error_detail = consultation_context.get("error", "No error details available") if isinstance(consultation_context, dict) else str(consultation_context)

                self.logger.error(f"OQ generation returned consultation requirement: {oq_data}")
                self.logger.error(f"Consultation type: {consultation_type}")
                self.logger.error(f"Error detail: {error_detail[:500] if len(error_detail) > 500 else error_detail}")

                raise RuntimeError(
                    f"OQ generation failed: {consultation_type} - {error_detail[:200] if len(error_detail) > 200 else error_detail}"
                )

            # Unexpected result type
            self.logger.error(f"CRITICAL: Unexpected OQ workflow result type: {type(oq_result)}")
            self.logger.error(f"Result content preview: {str(oq_result)[:500]}")
            raise ValueError(
                f"Unexpected OQ workflow result type: {type(oq_result)}"
            )

        except Exception as e:
            self.logger.error(f"OQ generation failed: {e}")
            # Re-raise to trigger consultation
            raise

    @step
    @observe(name="oq-test-generation", as_type="span")
    async def complete_workflow(
        self,
        ctx: Context,
        ev: OQTestSuiteEvent
    ) -> StopEvent:
        """
        Complete the unified workflow and return final results with OQ test generation traceability.

        Args:
            ctx: Workflow context
            ev: OQTestSuiteEvent with generated test suite

        Returns:
            StopEvent with comprehensive workflow results
        """
        # Get current observation for traceability
        # Note: get_current_observation() not available in this langfuse version
        # Langfuse @observe decorator handles observation context automatically
        obs = None

        # Get all stored results using safe context operations
        workflow_start_time = await safe_context_get(ctx, "workflow_start_time", None)
        document_path = await safe_context_get(ctx, "document_path", "unknown")

        # Calculate total processing time
        total_time = datetime.now(UTC) - workflow_start_time if workflow_start_time else None

        # Process OQ test suite results (only event type we handle now)
        status = "completed_with_oq_tests"
        oq_results = {
            "test_suite_id": ev.test_suite.suite_id,
            "total_tests": ev.test_suite.total_test_count,
            "coverage_percentage": ev.test_suite.coverage_percentage,
            "review_required": ev.test_suite.review_required,
            "generation_successful": ev.generation_successful
        }

        # Log generation start to Langfuse
        if obs:
            obs.update(metadata={
                "oq.gamp_category": ev.test_suite.gamp_category,
                "oq.required_count": len(ev.test_suite.test_cases),
                "oq.strategy": ev.test_suite.validation_approach,
                "oq.suite_id": ev.test_suite.suite_id,
                "workflow_session_id": self._workflow_session_id
            })

        # CRITICAL FIX #6: Serialize test suite to YAML BEFORE any filesystem operations
        # This ensures YAML is available in workflow results even if filesystem save fails
        try:
            test_suite_dict: dict[str, Any] = ev.test_suite.model_dump(
                mode='json',
                exclude_none=True
            )

            test_suite_yaml: str = yaml.dump(
                test_suite_dict,
                default_flow_style=False,
                allow_unicode=True,
                sort_keys=False
            )

            # Store in oq_results IMMEDIATELY (before any filesystem operations)
            oq_results["test_suite_yaml"] = test_suite_yaml

            self.logger.info(
                f"✅ Serialized test suite to YAML ({len(test_suite_yaml)} characters). "
                f"YAML stored in results before filesystem save."
            )
            flush_output()

        except Exception as e:
            # YAML serialization failed - this is CRITICAL (cannot generate valid output)
            self.logger.error(f"❌ CRITICAL: Failed to serialize test suite to YAML: {e}")
            import traceback
            self.logger.error(f"Stack trace:\n{traceback.format_exc()}")
            raise RuntimeError(
                f"Test suite YAML serialization failed: {e!s}. "
                f"Cannot generate valid YAML output for worker artifact storage. "
                f"This indicates a data model or serialization issue."
            ) from e

        # NOW attempt filesystem save (this can fail without losing YAML)
        try:
            import json
            from pathlib import Path

            # CRITICAL: Use absolute path to ensure writes target writable Docker volume
            # The /app/output directory is mounted as writable (not read-only like /app/main)
            output_dir = Path("/app/output/test_suites")
            output_dir.mkdir(parents=True, exist_ok=True)

            # Generate filename with suite ID and timestamp
            timestamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
            output_file = output_dir / f"test_suite_{ev.test_suite.suite_id}_{timestamp}.json"

            # Create comprehensive test suite data for saving
            test_suite_data = {
                "suite_id": ev.test_suite.suite_id,
                "gamp_category": ev.test_suite.gamp_category,
                "document_name": ev.test_suite.document_name,
                "test_cases": [test.dict() for test in ev.test_suite.test_cases],
                "metadata": ev.test_suite.metadata,
                "total_test_count": ev.test_suite.total_test_count,
                "coverage_percentage": ev.test_suite.coverage_percentage,
                "requirements_coverage": ev.test_suite.requirements_coverage,
                "test_categories": ev.test_suite.test_categories,
                "estimated_execution_time": ev.test_suite.estimated_execution_time,
                "generation_timestamp": ev.test_suite.generation_timestamp.isoformat(),
                "validation_approach": ev.test_suite.validation_approach,
                "pharmaceutical_compliance": ev.test_suite.pharmaceutical_compliance,
                "review_required": ev.test_suite.review_required,
                "timestamp": datetime.now(UTC).isoformat(),
                "workflow_session_id": self._workflow_session_id,
                "generation_method": ev.test_suite.generation_method
            }

            self.logger.info(f"Attempting to save test suite to filesystem: {output_file}")

            # Save test suite to JSON file
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(test_suite_data, f, indent=2, default=str)

            self.logger.info(f"✅ Test suite saved successfully to {output_file}")
            self.logger.info(f"📁 File contains {len(ev.test_suite.test_cases)} test cases")
            flush_output()

            # Add file info to oq_results for tracking
            oq_results["output_file"] = str(output_file)
            oq_results["file_saved"] = True
            # NOTE: test_suite_yaml already stored in oq_results before filesystem operations

            # Add electronic signature for test generation (21 CFR Part 11)
            config = get_config()
            if self.enable_part11_compliance and self.signature_service and not config.validation_mode.validation_mode:
                try:
                    signature_binding = self.signature_service.bind_signature_to_record(
                        record_id=ev.test_suite.suite_id,
                        record_content={
                            "action": "test_suite_generation",
                            "test_suite_id": ev.test_suite.suite_id,
                            "test_count": len(ev.test_suite.test_cases),
                            "gamp_category": ev.test_suite.gamp_category,
                            "document": ev.test_suite.document_name,
                            "timestamp": datetime.now(UTC).isoformat()
                        },
                        signer_name=getattr(config, "user_name", "System"),
                        signer_id=getattr(config, "user_id", "system"),
                        signature_meaning=SignatureMeaning.APPROVED,
                        additional_context={
                            "workflow_session": self._workflow_session_id,
                            "confidence_score": getattr(ev.test_suite, "confidence_score", 0.0)
                        }
                    )

                    self.logger.info(f"[SIGNATURE] Test suite signed: {signature_binding.signature_id}")
                    oq_results["signature_id"] = signature_binding.signature_id
                    oq_results["signed"] = True

                except Exception as sig_e:
                    self.logger.warning(f"[SIGNATURE] Electronic signature failed: {sig_e}")
                    # Continue without signature in case of error
                    oq_results["signed"] = False
                    oq_results["signature_error"] = str(sig_e)
            elif config.validation_mode.validation_mode:
                self.logger.info("[SIGNATURE] Skipping signature in validation mode")
                oq_results["signed"] = False
                oq_results["signature_reason"] = "validation_mode"

            # Add ALCOA+ record for test suite generation with complete metadata
            try:
                import os
                import platform
                import sys

                alcoa_validator = ALCOAPlusValidator()

                # Capture ALL test IDs for complete traceability
                all_test_ids = [t.test_id for t in ev.test_suite.test_cases]
                test_categories_count = {}
                for t in ev.test_suite.test_cases:
                    cat = t.test_category
                    test_categories_count[cat] = test_categories_count.get(cat, 0) + 1

                alcoa_record = alcoa_validator.create_data_record(
                    data={
                        "action": "test_suite_generation",
                        "test_suite_id": ev.test_suite.suite_id,
                        "test_count": len(ev.test_suite.test_cases),
                        "gamp_category": ev.test_suite.gamp_category,
                        "regulatory_basis": "GAMP-5, 21 CFR Part 11",
                        "compliance_standards": ["GAMP-5", "21 CFR Part 11", "ALCOA+"],
                        "document": ev.test_suite.document_name,
                        "all_test_ids": all_test_ids,  # Complete list of ALL test IDs
                        "test_categories": test_categories_count,  # Distribution of test types
                        "timestamp": datetime.now(UTC).isoformat()
                    },
                    user_id=getattr(config, "user_name", "System"),
                    agent_name="oq_generator",
                    activity="test_suite_generation",
                    metadata={
                        "workflow_id": str(self.workflow_id),
                        "document_id": ev.test_suite.document_name,
                        "suite_id": ev.test_suite.suite_id,
                        "test_count": len(ev.test_suite.test_cases),
                        "execution_start": workflow_start_time.isoformat() if workflow_start_time else None,
                        "execution_duration_seconds": (datetime.now(UTC) - workflow_start_time).total_seconds() if workflow_start_time else None,
                        "document_path": str(output_file) if output_file else None,
                        # System environment for complete traceability
                        "python_version": sys.version,
                        "platform": platform.platform(),
                        "hostname": platform.node(),
                        "processor": platform.processor(),
                        "llamaindex_version": "0.12.0",  # Should import and check
                        "environment": os.environ.get("VALIDATION_MODE", "production"),
                        "user": os.environ.get("USER", "unknown"),
                        # Complete test coverage info
                        "total_test_steps": sum(len(t.test_steps) for t in ev.test_suite.test_cases),
                        "avg_steps_per_test": sum(len(t.test_steps) for t in ev.test_suite.test_cases) / len(ev.test_suite.test_cases) if ev.test_suite.test_cases else 0,
                        "risk_distribution": {"low": 0, "medium": 0, "high": 0, "critical": 0}  # Will be populated
                    }
                )

                # Populate risk distribution
                for t in ev.test_suite.test_cases:
                    risk = t.risk_level
                    if risk in alcoa_record["metadata"]["risk_distribution"]:
                        alcoa_record["metadata"]["risk_distribution"][risk] += 1
                self.logger.info(f"[ALCOA+] Created test suite record with hash: {alcoa_record.get('data_hash', 'N/A')[:8]}...")
                oq_results["alcoa_record_created"] = True
                oq_results["data_hash"] = alcoa_record.get("data_hash", "")[:16]  # Store partial hash
            except Exception as alcoa_e:
                self.logger.warning(f"[ALCOA+] Failed to create test suite record: {alcoa_e}")
                oq_results["alcoa_record_created"] = False

        except Exception as e:
            # Filesystem save failed - BUT YAML is already preserved in oq_results
            self.logger.error(f"❌ Failed to save test suite to filesystem: {e}")
            self.logger.warning(
                f"Filesystem save failed, but YAML serialization succeeded "
                f"({len(oq_results.get('test_suite_yaml', ''))} characters). "
                f"Test suite YAML will be returned in workflow results."
            )
            import traceback
            self.logger.error(f"Filesystem error details:\n{traceback.format_exc()}")

            # Add error info to results but don't fail the workflow
            oq_results["file_saved"] = False
            oq_results["save_error"] = str(e)
            # NOTE: test_suite_yaml is already in oq_results from serialization step

        # Get all context data with safe defaults
        categorization_result = await safe_context_get(ctx, "categorization_result", None)
        planning_event = await safe_context_get(ctx, "planning_event", None)
        agent_results = await safe_context_get(ctx, "collected_results", [])

        # Compile final results with main.py compatible structure
        final_results = {
            # Summary section for main.py display compatibility
            "summary": {
                "status": status,
                "workflow_duration_seconds": total_time.total_seconds() if total_time else 0.0,
                "category": categorization_result.gamp_category.value if categorization_result else None,
                "confidence": categorization_result.confidence_score if categorization_result else 0.0,
                "review_required": categorization_result.review_required if categorization_result else False,
                "estimated_test_count": planning_event.estimated_test_count if planning_event else 0,
                "timeline_estimate_days": ((planning_event.estimated_test_count * 0.5) / 8.0) if planning_event else 0,
                "agents_coordinated": len(agent_results),
                "coordination_success_rate": (len([r for r in agent_results if r.success]) / len(agent_results)) if agent_results else 0.0
            },

            # Detailed workflow metadata
            "workflow_metadata": {
                "session_id": self._workflow_session_id,
                "document_path": document_path,
                "start_time": workflow_start_time.isoformat() if workflow_start_time else None,
                "completion_time": datetime.now(UTC).isoformat(),
                "total_processing_time": total_time.total_seconds() if total_time else None,
                "phoenix_enabled": self.enable_phoenix
            },

            # Top-level status for backward compatibility
            "status": status,

            # Categorization results
            "categorization": {
                "category": categorization_result.gamp_category.value if categorization_result else None,
                "gamp_category": categorization_result.gamp_category.value if categorization_result else None,
                "confidence": categorization_result.confidence_score if categorization_result else 0.0,
                "confidence_score": categorization_result.confidence_score if categorization_result else 0.0,
                "review_required": categorization_result.review_required if categorization_result else False
            } if categorization_result else None,

            # Planning results
            "planning": {
                "estimated_test_count": planning_event.estimated_test_count if planning_event else 0,
                "test_strategy": planning_event.test_strategy if planning_event else None,
                "agent_requests_processed": len(agent_results)
            } if planning_event else None,

            # Agent coordination results
            "agent_coordination": {
                "total_agents": len(agent_results),
                "successful_agents": len([r for r in agent_results if r.success]),
                "failed_agents": len([r for r in agent_results if not r.success])
            },

            # OQ generation results
            "oq_generation": oq_results,

            # Additional workflow results
            "workflow_results": ev.workflow_results if hasattr(ev, "workflow_results") else None
        }

        # Add test suite YAML for worker artifact persistence (top-level key)
        # Validate that YAML serialization succeeded before accessing
        if "test_suite_yaml" not in oq_results:
            # This should NEVER happen (serialization raises RuntimeError on failure)
            # But adding explicit check for defensive programming
            raise RuntimeError(
                "CRITICAL: test_suite_yaml not found in OQ results. "
                "This indicates test suite YAML serialization failed but error was not caught. "
                f"Available keys in oq_results: {list(oq_results.keys())}"
            )

        final_results["test_suite"] = oq_results["test_suite_yaml"]

        # CRITICAL FIX: Add top-level gamp_category for worker_executor compatibility
        # Worker expects workflow_result.get("gamp_category") to return integer value
        # NO FALLBACK LOGIC: Must have valid categorization result to proceed
        if not categorization_result:
            available_keys = list(final_results.keys())
            raise RuntimeError(
                f"CRITICAL: categorization_result is None. "
                f"Cannot extract GAMP category for final results. "
                f"This indicates categorization step failed or didn't persist results. "
                f"Available final_results keys: {available_keys}"
            )

        final_results["gamp_category"] = categorization_result.gamp_category.value

        # Log generation completion to Langfuse
        if obs:
            obs.update(output={
                "test_count": len(ev.test_suite.test_cases),
                "test_suite_present": "test_suite" in final_results,
                "test_suite_size_bytes": len(oq_results["test_suite_yaml"]) if "test_suite_yaml" in oq_results else 0,
                "status": status,
                "workflow_duration_seconds": total_time.total_seconds() if total_time else 0.0
            })

        self.logger.info(f"[COMPLETE] Unified workflow completed with status: {status}")
        if total_time:
            self.logger.info(f"[TIMING] Total processing time: {total_time.total_seconds():.2f} seconds")
        flush_output()

        # Enhanced Phoenix Observability - temporarily disabled for testing
        # if self.enable_phoenix:
        #     try:
        #         self.logger.info("🔍 Running enhanced Phoenix observability analysis...")
        #
        #         # Initialize enhanced observability components
        #         phoenix_client = PhoenixEnhancedClient()
        #         analyzer = AutomatedTraceAnalyzer(phoenix_client)
        #
        #         # Query recent traces for this workflow session
        #         traces = await phoenix_client.query_workflow_traces(
        #             workflow_type="UnifiedTestGenerationWorkflow",
        #             hours=1  # Fixed parameter name
        #         )
        #
        #         # Analyze traces for compliance violations
        #         violations = await analyzer.analyze_compliance_violations(hours=24)
        #
        #         # Generate compliance dashboard
        #         dashboard_path = await analyzer.generate_compliance_dashboard(hours=24)
        #
        #         # Add enhanced observability results to final results
        #         final_results["enhanced_observability"] = {
        #             "traces_analyzed": len(traces),
        #             "compliance_violations": len(violations),
        #             "dashboard_generated": str(dashboard_path) if dashboard_path else None,
        #             "critical_violations": len([v for v in violations if v.severity == "CRITICAL"]),
        #             "regulatory_status": "COMPLIANT" if len(violations) == 0 else "NON_COMPLIANT"
        #         }
        #
        #         if violations:
        #             self.logger.warning(f"⚠️ Found {len(violations)} compliance violations")
        #             final_results["enhanced_observability"]["violations"] = [
        #                 {
        #                     "type": v.violation_type,
        #                     "severity": v.severity,
        #                     "description": v.description
        #                 } for v in violations[:5]  # Show first 5 violations
        #             ]
        #         else:
        #             self.logger.info("✅ No compliance violations detected")
        #
        #         self.logger.info(f"[CATEGORIZATION] Compliance dashboard generated: {dashboard_path}")
        #
        #     except Exception as e:
        #         self.logger.error(f"Enhanced observability analysis failed: {e}")
        #         final_results["enhanced_observability"] = {
        #             "error": str(e),
        #             "status": "failed"
        #         }

        return StopEvent(result=final_results)


# Convenience function for main.py compatibility
async def run_unified_test_generation_workflow(
    urs_content: str | None = None,
    document_name: str = "test_document",
    document_version: str = "1.0",
    author: str = "system",
    timeout: int = 900,
    verbose: bool = False,
    enable_error_handling: bool = True,
    confidence_threshold: float = 0.5,
    enable_document_processing: bool = True,
    enable_parallel_coordination: bool = True,
    document_path: str | None = None,
    validation_mode: bool = False,
    **kwargs
) -> dict[str, Any]:
    """
    Run the unified test generation workflow with compatibility for main.py.
    
    Args:
        urs_content: Document content (deprecated, use document_path)
        document_name: Name of the document
        document_version: Version of the document
        author: Author of the document
        timeout: Workflow timeout in seconds
        verbose: Enable verbose logging
        enable_error_handling: Enable error handling
        confidence_threshold: Confidence threshold for categorization
        enable_document_processing: Enable document processing
        enable_parallel_coordination: Enable parallel coordination
        document_path: Path to the document to process
        validation_mode: Enable validation mode (bypasses consultation for testing)
        **kwargs: Additional arguments
        
    Returns:
        Dictionary containing workflow results
    """
    # Temporarily set validation mode in config if requested
    original_validation_mode = None
    if validation_mode:
        original_validation_mode = config.validation_mode.validation_mode
        config.validation_mode.validation_mode = True
        logger.warning("VALIDATION MODE ENABLED: Consultations will be bypassed for testing")

    try:
        # Create workflow instance
        workflow = UnifiedTestGenerationWorkflow(
            timeout=timeout,
            verbose=verbose,
            enable_parallel_coordination=enable_parallel_coordination,
            enable_phoenix=True,
            enable_human_consultation=True
        )

        # Determine document path - prefer explicit document_path
        if document_path:
            doc_path = document_path
        else:
            # If we only have content, we need to create a temporary file
            # For now, raise error if no path provided
            raise ValueError("document_path is required for unified workflow")

        # Run the workflow
        result = await workflow.run(document_path=doc_path)

        # Handle different result formats
        if hasattr(result, "result"):
            return result.result
        return result

    except Exception as e:
        logger.error(f"Unified workflow failed: {e}")
        return {
            "status": "failed",
            "error": str(e),
            "workflow_metadata": {
                "session_id": workflow._workflow_session_id,
                "failure_reason": "workflow_execution_error"
            }
        }
    finally:
        # Restore original validation mode if it was modified
        if original_validation_mode is not None:
            config.validation_mode.validation_mode = original_validation_mode
            logger.info("Validation mode restored to original setting")


# Export the main workflow class and convenience function
__all__ = ["UnifiedTestGenerationWorkflow", "run_unified_test_generation_workflow"]
