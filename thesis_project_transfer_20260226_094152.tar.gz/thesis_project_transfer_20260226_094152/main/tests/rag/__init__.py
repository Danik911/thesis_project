"""RAG workflow test suite."""
