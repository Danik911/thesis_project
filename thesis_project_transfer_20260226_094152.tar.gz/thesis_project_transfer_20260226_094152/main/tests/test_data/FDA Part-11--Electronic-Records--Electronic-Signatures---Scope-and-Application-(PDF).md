# Guidance for Industry

# Part 11, Electronic Records; Electronic Signatures — Scope and Application

U.S. Department of Health and Human Services

Food and Drug Administration

Center for Drug Evaluation and Research (CDER)

Center for Biologics Evaluation and Research (CBER)

Center for Devices and Radiological Health (CDRH)

Center for Food Safety and Applied Nutrition (CFSAN)

Center for Veterinary Medicine (CVM)

Office of Regulatory Affairs (ORA)

August 2003

Pharmaceutical CGMPs
---
# Guidance for Industry

# Part 11, Electronic Records; Electronic Signatures — Scope and Application

Division of Drug Information, HFD-240

Center for Drug Evaluation and Research (CDER)

(Tel) 301-827-4573

http://www.fda.gov/cder/guidance/index.htm

or

Office of Communication, Training and Manufacturers Assistance, HFM-40

Center for Biologics Evaluation and Research (CBER)

http://www.fda.gov/cber/guidelines.htm

Phone: the Voice Information System at 800 -835-4709 or 301-827-1800

or

Communications Staff (HFV-12),

Center for Veterinary Medicine (CVM)

(Tel) 301-594-1755

http://www.fda.gov/cvm/guidance/guidance.html

or

Division of Small Manufacturers Assistance (HFZ-220)

http://www.fda.gov/cdrh/ggpmain.html

Manufacturers Assistance Phone Number: 800.638.2041 or 301.443.6597

Internt'l Staff Phone: 301.827.3993

or

Center for Food Safety and Applied Nutrition (CFSAN)

http://www.cfsan.fda.gov/~dms/guidance.html

U.S. Department of Health and Human Services

Food and Drug Administration

Center for Drug Evaluation and Research (CDER)

Center for Biologics Evaluation and Research (CBER)

Center for Devices and Radiological Health (CDRH)

Center for Food Safety and Applied Nutrition (CFSAN)

Center for Veterinary Medicine (CVM)

Office of Regulatory Affairs (ORA)

August 2003

Pharmaceutical CGMPs
---
# TABLE OF CONTENTS

# I. INTRODUCTION

............................................................................................................. 1

# II. BACKGROUND

............................................................................................................... 2

# III. DISCUSSION

.................................................................................................................... 3

# A. Overall Approach to Part 11 Requirements

......................................................................................................... 3

# B. Details of Approach – Scope of Part 11

................................................................................................................ 4

# 1. Narrow Interpretation of Scope

............................................................................................................................. 4

# 2. Definition of Part 11 Records

........................................................................................................................ 5

# C. Approach to Specific Part 11 Requirements

................................................................................................................ 6

# 1. Validation

............................................................................................................................. 6

# 2. Audit Trail

............................................................................................................................ 6

# 3. Legacy Systems

...................................................................................................................... 7

# 4. Copies of Records

.................................................................................................................. 7

# 5. Record Retention

................................................................................................................... 8

# IV. REFERENCES

.................................................................................................................. 9
---
# Contains Nonbinding Recommendations

# 1 Guidance for Industry

# Part 11,  Electronic Records; Electronic Signatures — Scope and Application

This guidance represents the Food and Drug Administration's (FDA's) current thinking on this topic. It does not create or confer any rights for or on any person and does not operate to bind FDA or the public. You can use an alternative approach if the approach satisfies the requirements of the applicable statutes and regulations. If you want to discuss an alternative approach, contact the FDA staff responsible for implementing this guidance. If you cannot identify the appropriate FDA staff, call the appropriate number listed on the title page of this guidance.

# I. INTRODUCTION

This guidance is intended to describe the Food and Drug Administration's (FDA’s) current thinking regarding the scope and application of part 11 of Title 21 of the Code of Federal Regulations; Electronic Records; Electronic Signatures (21 CFR Part 11).2

This document provides guidance to persons who, in fulfillment of a requirement in a statute or another part of FDA's regulations to maintain records or submit information to FDA,3 have chosen to maintain the records or submit designated information electronically and, as a result, have become subject to part 11. Part 11 applies to records in electronic form that are created, modified, maintained, archived, retrieved, or transmitted under any records requirements set forth in Agency regulations. Part 11 also applies to electronic records submitted to the Agency under the Federal Food, Drug, and Cosmetic Act (the Act) and the Public Health Service Act (the PHS Act), even if such records are not specifically identified in Agency regulations (§ 11.1). The underlying requirements set forth in the Act, PHS Act, and FDA regulations (other than part 11) are referred to in this guidance document as predicate rules.

1 This guidance has been prepared by the Office of Compliance in the Center for Drug Evaluation and Research (CDER) in consultation with the other Agency centers and the Office of Regulatory Affairs at the Food and Drug Administration.

2 62 FR 13430

3 These requirements include, for example, certain provisions of the Current Good Manufacturing Practice regulations (21 CFR Part 211), the Quality System regulation (21 CFR Part 820), and the Good Laboratory Practice for Nonclinical Laboratory Studies regulations (21 CFR Part 58).
---
# Contains Nonbinding Recommendations

As an outgrowth of its current good manufacturing practice (CGMP) initiative for human and animal drugs and biologics,⁴ FDA is re-examining part 11 as it applies to all FDA regulated products. We anticipate initiating rulemaking to change part 11 as a result of that re-examination. This guidance explains that we will narrowly interpret the scope of part 11. While the re-examination of part 11 is under way, we intend to exercise enforcement discretion with respect to certain part 11 requirements. That is, we do not intend to take enforcement action to enforce compliance with the validation, audit trail, record retention, and record copying requirements of part 11 as explained in this guidance. However, records must still be maintained or submitted in accordance with the underlying predicate rules, and the Agency can take regulatory action for noncompliance with such predicate rules.

In addition, we intend to exercise enforcement discretion and do not intend to take (or recommend) action to enforce any part 11 requirements with regard to systems that were operational before August 20, 1997, the effective date of part 11 (commonly known as legacy systems) under the circumstances described in section III.C.3 of this guidance.

Note that part 11 remains in effect and that this exercise of enforcement discretion applies only as identified in this guidance.

FDA's guidance documents, including this guidance, do not establish legally enforceable responsibilities. Instead, guidances describe the Agency's current thinking on a topic and should be viewed only as recommendations, unless specific regulatory or statutory requirements are cited. The use of the word should in Agency guidances means that something is suggested or recommended, but not required.

# II. BACKGROUND

In March of 1997, FDA issued final part 11 regulations that provide criteria for acceptance by FDA, under certain circumstances, of electronic records, electronic signatures, and handwritten signatures executed to electronic records as equivalent to paper records and handwritten signatures executed on paper. These regulations, which apply to all FDA program areas, were intended to permit the widest possible use of electronic technology, compatible with FDA's responsibility to protect the public health.

After part 11 became effective in August 1997, significant discussions ensued among industry, contractors, and the Agency concerning the interpretation and implementation of the regulations. FDA has (1) spoken about part 11 at many conferences and met numerous times with an industry coalition and other interested parties in an effort to hear more about potential part 11 issues; (2) published a compliance policy guide, CPG 7153.17: Enforcement Policy: 21 CFR Part 11; Electronic Records; Electronic Signatures; and (3) published numerous draft guidance documents including the following:

4 See Pharmaceutical CGMPs for the 21st Century: A Risk-Based Approach; A Science and Risk-Based Approach to Product Quality Regulation Incorporating an Integrated Quality Systems Approach at www.fda.gov/oc/guidance/gmp.html.
---
# Contains Nonbinding Recommendations

• 21 CFR Part 11; Electronic Records; Electronic Signatures, Validation

• 21 CFR Part 11; Electronic Records; Electronic Signatures, Glossary of Terms

• 21 CFR Part 11; Electronic Records; Electronic Signatures, Time Stamps

• 21 CFR Part 11; Electronic Records; Electronic Signatures, Maintenance of Electronic Records

• 21 CFR Part 11; Electronic Records; Electronic Signatures, Electronic Copies of Electronic Records

Throughout all of these communications, concerns have been raised that some interpretations of the part 11 requirements would (1) unnecessarily restrict the use of electronic technology in a manner that is inconsistent with FDA's stated intent in issuing the rule, (2) significantly increase the costs of compliance to an extent that was not contemplated at the time the rule was drafted, and (3) discourage innovation and technological advances without providing a significant public health benefit. These concerns have been raised particularly in the areas of part 11 requirements for validation, audit trails, record retention, record copying, and legacy systems.

As a result of these concerns, we decided to review the part 11 documents and related issues, particularly in light of the Agency's CGMP initiative. In the Federal Register of February 4, 2003 (68 FR 5645), we announced the withdrawal of the draft guidance for industry, 21 CFR Part 11; Electronic Records; Electronic Signatures, Electronic Copies of Electronic Records. We had decided we wanted to minimize industry time spent reviewing and commenting on the draft guidance when that draft guidance may no longer represent our approach under the CGMP initiative. Then, in the Federal Register of February 25, 2003 (68 FR 8775), we announced the withdrawal of the part 11 draft guidance documents on validation, glossary of terms, time stamps, maintenance of electronic records, and CPG 7153.17. We received valuable public comments on these draft guidances, and we plan to use that information to help with future decision-making with respect to part 11. We do not intend to re-issue these draft guidance documents or the CPG.

We are now re-examining part 11, and we anticipate initiating rulemaking to revise provisions of that regulation. To avoid unnecessary resource expenditures to comply with part 11 requirements, we are issuing this guidance to describe how we intend to exercise enforcement discretion with regard to certain part 11 requirements during the re-examination of part 11. As mentioned previously, part 11 remains in effect during this re-examination period.

# III. DISCUSSION

# A. Overall Approach to Part 11 Requirements

Although we withdrew the draft guidance on time stamps, our current thinking has not changed in that when using time stamps for systems that span different time zones, we do not expect you to record the signer’s local time. When using time stamps, they should be implemented with a clear understanding of the time zone reference used. In such instances, system documentation should explain time zone references as well as zone acronyms or other naming conventions.
---
# Contains Nonbinding Recommendations

As described in more detail below, the approach outlined in this guidance is based on three main elements:

- Part 11 will be interpreted narrowly; we are now clarifying that fewer records will be considered subject to part 11.
- For those records that remain subject to part 11, we intend to exercise enforcement discretion with regard to part 11 requirements for validation, audit trails, record retention, and record copying in the manner described in this guidance and with regard to all part 11 requirements for systems that were operational before the effective date of part 11 (also known as legacy systems).
- We will enforce all predicate rule requirements, including predicate rule record and recordkeeping requirements.

It is important to note that FDA's exercise of enforcement discretion as described in this guidance is limited to specified part 11 requirements (setting aside legacy systems, as to which the extent of enforcement discretion, under certain circumstances, will be more broad). We intend to enforce all other provisions of part 11 including, but not limited to, certain controls for closed systems in § 11.10. For example, we intend to enforce provisions related to the following controls and requirements:

- limiting system access to authorized individuals
- use of operational system checks
- use of authority checks
- use of device checks
- determination that persons who develop, maintain, or use electronic systems have the education, training, and experience to perform their assigned tasks
- establishment of and adherence to written policies that hold individuals accountable for actions initiated under their electronic signatures
- appropriate controls over systems documentation
- controls for open systems corresponding to controls for closed systems bulleted above (§ 11.30)
- requirements related to electronic signatures (e.g., §§ 11.50, 11.70, 11.100, 11.200, and 11.300)

We expect continued compliance with these provisions, and we will continue to enforce them. Furthermore, persons must comply with applicable predicate rules, and records that are required to be maintained or submitted must remain secure and reliable in accordance with the predicate rules.

# B. Details of Approach – Scope of Part 11

# 1. Narrow Interpretation of Scope

We understand that there is some confusion about the scope of part 11. Some have understood the scope of part 11 to be very broad. We believe that some of those broad interpretations could...
---
# Contains Nonbinding Recommendations

lead to unnecessary controls and costs and could discourage innovation and technological advances without providing added benefit to the public health. As a result, we want to clarify that the Agency intends to interpret the scope of part 11 narrowly.

Under the narrow interpretation of the scope of part 11, with respect to records required to be maintained under predicate rules or submitted to FDA, when persons choose to use records in electronic format in place of paper format, part 11 would apply. On the other hand, when persons use computers to generate paper printouts of electronic records, and those paper records meet all the requirements of the applicable predicate rules and persons rely on the paper records to perform their regulated activities, FDA would generally not consider persons to be "using electronic records in lieu of paper records" under §§ 11.2(a) and 11.2(b). In these instances, the use of computer systems in the generation of paper records would not trigger part 11.

# 2. Definition of Part 11 Records

Under this narrow interpretation, FDA considers part 11 to be applicable to the following records or signatures in electronic format (part 11 records or signatures):

- Records that are required to be maintained under predicate rule requirements and that are maintained in electronic format in place of paper format. On the other hand, records (and any associated signatures) that are not required to be retained under predicate rules, but that are nonetheless maintained in electronic format, are not part 11 records. We recommend that you determine, based on the predicate rules, whether specific records are part 11 records. We recommend that you document such decisions.
- Records that are required to be maintained under predicate rules, that are maintained in electronic format in addition to paper format, and that are relied on to perform regulated activities. In some cases, actual business practices may dictate whether you are using electronic records instead of paper records under § 11.2(a). For example, if a record is required to be maintained under a predicate rule and you use a computer to generate a paper printout of the electronic records, but you nonetheless rely on the electronic record to perform regulated activities, the Agency may consider you to be using the electronic record instead of the paper record. That is, the Agency may take your business practices into account in determining whether part 11 applies. Accordingly, we recommend that, for each record required to be maintained under predicate rules, you determine in advance whether you plan to rely on the electronic record or paper record to perform regulated activities. We recommend that you document this decision (e.g., in a Standard Operating Procedure (SOP), or specification document).
- Records submitted to FDA, under predicate rules (even if such records are not specifically identified in Agency regulations) in electronic format (assuming the records have been identified in docket number 92S-0251 as the types of submissions the Agency accepts in electronic format). However, a record that is not itself submitted, but is used.
---
# Contains Nonbinding Recommendations

in generating a submission, is not a part 11 record unless it is otherwise required to be maintained under a predicate rule and it is maintained in electronic format.

- Electronic signatures that are intended to be the equivalent of handwritten signatures, initials, and other general signings required by predicate rules. Part 11 signatures include electronic signatures that are used, for example, to document the fact that certain events or actions occurred in accordance with the predicate rule (e.g. approved, reviewed, and verified).

# C. Approach to Specific Part 11 Requirements

# 1. Validation

The Agency intends to exercise enforcement discretion regarding specific part 11 requirements for validation of computerized systems (§ 11.10(a) and corresponding requirements in § 11.30). Although persons must still comply with all applicable predicate rule requirements for validation (e.g., 21 CFR 820.70(i)), this guidance should not be read to impose any additional requirements for validation.

We suggest that your decision to validate computerized systems, and the extent of the validation, take into account the impact the systems have on your ability to meet predicate rule requirements. You should also consider the impact those systems might have on the accuracy, reliability, integrity, availability, and authenticity of required records and signatures. Even if there is no predicate rule requirement to validate a system, in some instances it may still be important to validate the system.

We recommend that you base your approach on a justified and documented risk assessment and a determination of the potential of the system to affect product quality and safety, and record integrity. For instance, validation would not be important for a word processor used only to generate SOPs.

For further guidance on validation of computerized systems, see FDA’s guidance for industry and FDA staff General Principles of Software Validation and also industry guidance such as the GAMP 4 Guide (See References).

# 2. Audit Trail

The Agency intends to exercise enforcement discretion regarding specific part 11 requirements related to computer-generated, time-stamped audit trails (§ 11.10 (e), (k)(2) and any corresponding requirement in §11.30). Persons must still comply with all applicable predicate rule requirements related to documentation of, for example, date (e.g., § 58.130(e)), time, or sequencing of events, as well as any requirements for ensuring that changes to records do not obscure previous entries.

Even if there are no predicate rule requirements to document, for example, date, time, or sequence of events in a particular instance, it may nonetheless be important to have audit trails or other physical, logical, or procedural security measures in place to ensure the trustworthiness and integrity of records.
---
# Contains Nonbinding Recommendations

We recommend that you base your decision on whether to apply audit trails, or other appropriate measures, on the need to comply with predicate rule requirements, a justified and documented risk assessment, and a determination of the potential effect on product quality and safety and record integrity. We suggest that you apply appropriate controls based on such an assessment. Audit trails can be particularly appropriate when users are expected to create, modify, or delete regulated records during normal operation.

# 3. Legacy Systems

The Agency intends to exercise enforcement discretion with respect to all part 11 requirements for systems that otherwise were operational prior to August 20, 1997, the effective date of part 11, under the circumstances specified below.

This means that the Agency does not intend to take enforcement action to enforce compliance with any part 11 requirements if all the following criteria are met for a specific system:

- The system was operational before the effective date.
- The system met all applicable predicate rule requirements before the effective date.
- The system currently meets all applicable predicate rule requirements.
- You have documented evidence and justification that the system is fit for its intended use (including having an acceptable level of record security and integrity, if applicable).

If a system has been changed since August 20, 1997, and if the changes would prevent the system from meeting predicate rule requirements, Part 11 controls should be applied to Part 11 records and signatures pursuant to the enforcement policy expressed in this guidance.

# 4. Copies of Records

The Agency intends to exercise enforcement discretion with regard to specific part 11 requirements for generating copies of records (§ 11.10 (b) and any corresponding requirement in §11.30). You should provide an investigator with reasonable and useful access to records during an inspection. All records held by you are subject to inspection in accordance with predicate rules (e.g., §§ 211.180(c), (d), and 108.35(c)(3)(ii)).

We recommend that you supply copies of electronic records by:

- Producing copies of records held in common portable formats when records are maintained in these formats
- Using established automated conversion or export methods, where available, to make copies in a more common format (examples of such formats include, but are not limited to, PDF, XML, or SGML)

Various guidance documents on information security are available (see References).

In this guidance document, we use the term legacy system to describe systems already in operation before the effective date of part 11.
---
# Contains Nonbinding Recommendations

In each case, we recommend that the copying process used produces copies that preserve the content and meaning of the record. If you have the ability to search, sort, or trend part 11 records, copies given to the Agency should provide the same capability if it is reasonable and technically feasible. You should allow inspection, review, and copying of records in a human readable form at your site using your hardware and following your established procedures and techniques for accessing records.

# 5. Record Retention

The Agency intends to exercise enforcement discretion with regard to the part 11 requirements for the protection of records to enable their accurate and ready retrieval throughout the records retention period (§ 11.10 (c) and any corresponding requirement in §11.30). Persons must still comply with all applicable predicate rule requirements for record retention and availability (e.g., §§ 211.180(c),(d), 108.25(g), and 108.35(h)).

We suggest that your decision on how to maintain records be based on predicate rule requirements and that you base your decision on a justified and documented risk assessment and a determination of the value of the records over time.

FDA does not intend to object if you decide to archive required records in electronic format to nonelectronic media such as microfilm, microfiche, and paper, or to a standard electronic file format (examples of such formats include, but are not limited to, PDF, XML, or SGML). Persons must still comply with all predicate rule requirements, and the records themselves and any copies of the required records should preserve their content and meaning. As long as predicate rule requirements are fully satisfied and the content and meaning of the records are preserved and archived, you can delete the electronic version of the records. In addition, paper and electronic record and signature components can co-exist (i.e., a hybrid situation) as long as predicate rule requirements are met and the content and meaning of those records are preserved.

Examples of hybrid situations include combinations of paper records (or other nonelectronic media) and electronic records, paper records and electronic signatures, or handwritten signatures executed to electronic records.
---
# IV. REFERENCES

# Food and Drug Administration References

1. Glossary of Computerized System and Software Development Terminology (Division of Field Investigations, Office of Regional Operations, Office of Regulatory Affairs, FDA 1995)
(http://www.fda.gov/ora/inspect_ref/igs/gloss.html)
2. General Principles of Software Validation; Final Guidance for Industry and FDA Staff (FDA, Center for Devices and Radiological Health, Center for Biologics Evaluation and Research, 2002)
(http://www.fda.gov/cdrh/comp/guidance/938.html)
3. Guidance for Industry, FDA Reviewers, and Compliance on Off-The-Shelf Software Use in Medical Devices (FDA, Center for Devices and Radiological Health, 1999)
(http://www.fda.gov/cdrh/ode/guidance/585.html)
4. Pharmaceutical CGMPs for the 21st Century: A Risk-Based Approach; A Science and Risk-Based Approach to Product Quality Regulation Incorporating an Integrated Quality Systems Approach (FDA 2002)
(http://www.fda.gov/oc/guidance/gmp.html)

# Industry References

1. The Good Automated Manufacturing Practice (GAMP) Guide for Validation of Automated Systems, GAMP 4 (ISPE/GAMP Forum, 2001)
(http://www.ispe.org/gamp/)
2. ISO/IEC 17799:2000 (BS 7799:2000) Information technology – Code of practice for information security management (ISO/IEC, 2000)
3. ISO 14971:2002 Medical Devices- Application of risk management to medical devices (ISO, 2001)