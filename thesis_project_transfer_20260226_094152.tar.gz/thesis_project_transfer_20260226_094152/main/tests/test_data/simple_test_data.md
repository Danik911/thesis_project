# Simple GAMP-5 Test Document

## URS-001: Environmental Monitoring System (EMS)

### 1. Introduction
This URS defines the requirements for an Environmental Monitoring System to monitor critical storage areas for temperature-sensitive pharmaceutical products.

### 2. Functional Requirements
- **URS-EMS-001**: The system shall continuously monitor temperature in all GMP storage areas.
- **URS-EMS-002**: Temperature readings shall be recorded at intervals not exceeding 5 minutes.
- **URS-EMS-003**: The system shall use vendor-supplied software without modification.
- **URS-EMS-004**: Temperature range: -80°C to +50°C with accuracy of ±0.5°C.
- **URS-EMS-005**: The system shall generate alerts when temperature deviates ±2°C from setpoint.

### 3. Regulatory Requirements
- **URS-EMS-006**: System shall maintain an audit trail per 21 CFR Part 11.
- **URS-EMS-007**: Electronic signatures shall use vendor's built-in functionality.
- **URS-EMS-008**: Data shall be retained for 7 years using vendor's archival feature.

This is a standard commercial off-the-shelf (COTS) environmental monitoring system that will be used as supplied by the vendor without any configuration or customization.